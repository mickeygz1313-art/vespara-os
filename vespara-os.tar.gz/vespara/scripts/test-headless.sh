#!/bin/bash
# Run the whole desktop without a screen and save a screenshot (needs grim).
# Useful for checking the UI on any machine that has the build deps.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export XDG_RUNTIME_DIR=$(mktemp -d); chmod 700 $XDG_RUNTIME_DIR
export WLR_BACKENDS=headless WLR_RENDERER=pixman WLR_HEADLESS_OUTPUTS=1 WLR_LIBINPUT_NO_DEVICES=1
export GSK_RENDERER=cairo WEBKIT_DISABLE_COMPOSITING_MODE=1 WEBKIT_DISABLE_DMABUF_RENDERER=1 GDK_BACKEND=wayland
export VESPARA_UI="$ROOT/shell/ui"
"$ROOT/compositor/build/vespara-wm" -s "dbus-run-session -- $ROOT/shell/vespara-shell" &
sleep 12
WAYLAND_DISPLAY=wayland-0 grim "${1:-vespara-shot.png}" && echo "saved ${1:-vespara-shot.png}"
kill %1
