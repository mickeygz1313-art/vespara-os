#!/bin/bash
# Boot the Vespara ISO in QEMU (on Arch: sudo pacman -S qemu-desktop).
#   ./scripts/run-qemu.sh out/vespara-*.iso            live boot only
#   ./scripts/run-qemu.sh out/vespara-*.iso --install  also attach a blank 20 GB disk to install onto
#   add --uefi to boot via UEFI (needs: sudo pacman -S edk2-ovmf)
ISO="${1:?usage: run-qemu.sh <iso> [--install] [--uefi]}"; shift || true
ARGS=(-m 4G -smp 2 -vga virtio -display gtk -cdrom "$ISO" -boot d -device virtio-net-pci,netdev=n -netdev user,id=n)
[ -w /dev/kvm ] && ARGS+=(-enable-kvm -cpu host)
for a in "$@"; do
  case "$a" in
    --install) [ -f vespara-disk.qcow2 ] || qemu-img create -f qcow2 vespara-disk.qcow2 20G
               ARGS+=(-drive file=vespara-disk.qcow2,if=virtio) ;;
    --uefi)    ARGS+=(-drive if=pflash,format=raw,readonly=on,file=/usr/share/edk2/x64/OVMF_CODE.4m.fd) ;;
  esac
done
exec qemu-system-x86_64 "${ARGS[@]}"
