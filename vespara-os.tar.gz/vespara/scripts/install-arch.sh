#!/bin/bash
# Build + install Vespara OS on Arch Linux (VM or real hardware).
# Run as your normal user (not root); it will sudo when needed.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX=/opt/vespara

echo "==> Installing dependencies"
sudo pacman -S --needed --noconfirm base-devel git meson ninja pkgconf \
  wayland wayland-protocols libxkbcommon pixman libinput libdrm mesa seatd hwdata \
  libxcb xcb-util-wm xcb-util-renderutil xcb-util-errors dbus xdg-utils \
  gtk4 gtk4-layer-shell webkitgtk-6.0 python-gobject python-cairo \
  foot grim slurp thunar mousepad firefox pavucontrol \
  papirus-icon-theme adwaita-icon-theme ttf-dejavu inter-font noto-fonts
sudo systemctl enable --now seatd.service
sudo usermod -aG seat "$USER" || true

# wlroots changes its API every release, so we pin 0.17 (the version the
# compositor is written against) and keep it out of the system's way in /opt.
if [ ! -f "$PREFIX/lib/pkgconfig/wlroots.pc" ]; then
  echo "==> Building wlroots 0.17"
  rm -rf /tmp/wlroots-build
  git clone --depth 1 --branch 0.17.4 https://gitlab.freedesktop.org/wlroots/wlroots.git /tmp/wlroots-build
  (cd /tmp/wlroots-build &&
   meson setup build --prefix="$PREFIX" --libdir=lib -Dxwayland=disabled -Dexamples=false -Dwerror=false &&
   ninja -C build && sudo ninja -C build install)
fi

echo "==> Building vespara-wm"
cd "$ROOT/compositor"
rm -rf build
export PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig"
export LDFLAGS="-Wl,-rpath,$PREFIX/lib"
meson setup build --prefix=/usr/local
ninja -C build
sudo ninja -C build install

echo "==> Installing shell, session, config"
sudo install -Dm755 "$ROOT/shell/vespara-shell"       /usr/local/bin/vespara-shell
sudo rm -rf /usr/local/share/vespara/ui /usr/local/share/vespara/config
sudo mkdir -p /usr/local/share/vespara
sudo cp -r "$ROOT/shell/ui" /usr/local/share/vespara/ui
sudo cp -r "$ROOT/config"   /usr/local/share/vespara/config
sudo install -Dm755 "$ROOT/session/vespara-session"   /usr/local/bin/vespara-session
sudo install -Dm755 "$ROOT/session/vespara-autostart" /usr/local/bin/vespara-autostart
sudo install -Dm644 "$ROOT/session/vespara.desktop"   /usr/share/wayland-sessions/vespara.desktop

echo
echo "Done. Log out or reboot (so the 'seat' group applies), then from a TTY run:"
echo "    vespara-session"
