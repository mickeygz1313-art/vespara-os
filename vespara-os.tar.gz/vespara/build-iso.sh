#!/bin/bash
# Build the Vespara OS live/installer ISO.
#
# Run this on Arch Linux (a VM is fine) as a NORMAL user that has sudo.
# Needs ~12 GB free disk space, 4 GB RAM, internet. Takes 20-40 minutes.
#
#   ./build-iso.sh                  full build -> out/vespara-*.iso
#   ./build-iso.sh --skip-packages  reuse packages from a previous run
#   ./build-iso.sh --profile-only   assemble the archiso profile, don't make the ISO
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="${BUILD_DIR:-$ROOT/build}"
OUT="$ROOT/out"
RELENG="${RELENG_DIR:-/usr/share/archiso/configs/releng}"
PKGS="$BUILD/pkgs"
REPO="$BUILD/repo"
PROFILE="$BUILD/profile"
SKIP_PKGS=0; PROFILE_ONLY=0
for a in "$@"; do
  case "$a" in
    --skip-packages) SKIP_PKGS=1 ;;
    --profile-only)  PROFILE_ONLY=1 ;;
    -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 1 ;;
  esac
done

say() { printf '\n\033[1;36m==>\033[0m \033[1m%s\033[0m\n' "$*"; }
die() { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }

# ------------------------------------------------------------------ 0. sanity
[ "$(id -u)" != 0 ] || die "run as a normal user (makepkg refuses root). The script uses sudo where needed."
if [ "${SKIP_CHECKS:-0}" != 1 ]; then
  command -v pacman >/dev/null || die "this must be run on Arch Linux (a VM is fine)."
  say "Installing build tools (archiso, base-devel, git)"
  sudo pacman -Sy --needed --noconfirm archiso base-devel git
  avail=$(df -BG --output=avail "$ROOT" | tail -1 | tr -dc 0-9)
  [ "${avail:-0}" -ge 10 ] || die "need at least 10 GB free in $ROOT (have ${avail}G)"
fi
[ -d "$RELENG" ] || die "archiso releng profile not found at $RELENG"

# ------------------------------------------------------------------ 1. verify package names
if [ "${SKIP_CHECKS:-0}" != 1 ]; then
  say "Checking that every package name exists in the Arch repos"
  names=$( { for d in wlroots-vespara vespara-desktop vespara-installer; do
               ( . "$ROOT/packaging/$d/PKGBUILD"; printf '%s\n' "${depends[@]:-}" "${makedepends[@]:-}" ); done
             grep -v '^#' "$ROOT/iso/packages.extra"; } |
           sed 's/[<>=].*//' | grep -v '^$' | grep -vE '^(wlroots-vespara|vespara-desktop|vespara-installer)$' | sort -u )
  missing=()
  for p in $names; do pacman -Si "$p" >/dev/null 2>&1 || pacman -Sg "$p" >/dev/null 2>&1 || missing+=("$p"); done
  if [ "${#missing[@]}" -gt 0 ]; then
    printf 'These packages were not found in your pacman repos:\n'; printf '  %s\n' "${missing[@]}"
    die "fix the names in packaging/*/PKGBUILD or iso/packages.extra (Arch renames packages sometimes), then rerun."
  fi
fi

# ------------------------------------------------------------------ 2. build packages
mkdir -p "$PKGS"
if [ "$SKIP_PKGS" = 0 ]; then
  rm -f "$PKGS"/*.pkg.tar.* 2>/dev/null || true
  export PKGDEST="$PKGS"

  say "Building wlroots-vespara (pinned wlroots 0.17.4)"
  # If gitlab.freedesktop.org is blocked, put wlroots-0.17.4.tar.gz in packaging/wlroots-vespara/
  ( cd "$ROOT/packaging/wlroots-vespara" && makepkg -sfi --noconfirm )

  say "Building vespara-desktop (compositor + shell + session)"
  VER=$(. "$ROOT/packaging/vespara-desktop/PKGBUILD"; echo "$pkgver")
  tar czf "$ROOT/packaging/vespara-desktop/vespara-$VER.tar.gz" \
      --transform "s,^,vespara-$VER/," --exclude=build --exclude='__pycache__' \
      -C "$ROOT" compositor shell config session
  ( cd "$ROOT/packaging/vespara-desktop" && makepkg -sf --noconfirm )

  say "Building vespara-installer"
  cp "$ROOT/installer/vespara-install" "$ROOT/packaging/vespara-installer/vespara-install"
  ( cd "$ROOT/packaging/vespara-installer" && makepkg -sf --noconfirm )
fi
ls "$PKGS"/*.pkg.tar.* >/dev/null 2>&1 || die "no packages in $PKGS"

# ------------------------------------------------------------------ 3. local repo
say "Creating local package repo"
rm -rf "$REPO"; mkdir -p "$REPO"
cp "$PKGS"/*.pkg.tar.* "$REPO"/
rm -f "$REPO"/*-debug-*
( cd "$REPO" && repo-add -q vespara.db.tar.gz ./*.pkg.tar.* )

# ------------------------------------------------------------------ 4. archiso profile
say "Assembling the archiso profile"
rm -rf "$PROFILE"; cp -r "$RELENG" "$PROFILE"

# branding
sed -i -E \
  -e 's|^iso_name=.*|iso_name="vespara"|' \
  -e 's|^iso_label=.*|iso_label="VESPARA_$(date +%Y%m)"|' \
  -e 's|^iso_publisher=.*|iso_publisher="Vespara OS"|' \
  -e 's|^iso_application=.*|iso_application="Vespara OS Live and Installer"|' \
  "$PROFILE/profiledef.sh"
for d in syslinux grub efiboot; do
  if [ -d "$PROFILE/$d" ]; then
    grep -rlI "Arch Linux" "$PROFILE/$d" | xargs -r sed -i 's/Arch Linux/Vespara OS/g' || true
  fi
done

# live networking: NetworkManager instead of networkd/iwd
find "$PROFILE/airootfs/etc/systemd/system" \( -name 'systemd-networkd*' -o -name 'iwd.service' \) -delete 2>/dev/null || true
rm -f "$PROFILE/airootfs/etc/os-release"

# our overlay (live user, autologin, os-release, pinned dock...)
cp -a "$ROOT/iso/airootfs/." "$PROFILE/airootfs/"

# offline copy of our repo, used by the installer
mkdir -p "$PROFILE/airootfs/opt"
cp -a "$REPO" "$PROFILE/airootfs/opt/vespara-repo"

# packages
[ -n "$(tail -c1 "$PROFILE/packages.x86_64")" ] && echo >>"$PROFILE/packages.x86_64"
grep -v '^#' "$ROOT/iso/packages.extra" | grep -v '^$' >>"$PROFILE/packages.x86_64"

# our repo is visible to mkarchiso
cat >>"$PROFILE/pacman.conf" <<EOF

[vespara]
SigLevel = Optional TrustAll
Server = file://$REPO
EOF

# permissions
cat >>"$PROFILE/profiledef.sh" <<'EOF'
file_permissions+=(["/etc/sudoers.d/10-vespara-live"]="0:0:440")
EOF

# Building inside a container (CI): pacman's download sandbox (Landlock) often fails there.
# Only add the option if this pacman version understands it.
add_pacman_opt() {
  local conf=$1 opt=$2
  sed -i "/^\[options\]/a $opt" "$conf"
  # pacman only WARNS about unknown directives (and exits 0), so look for the warning
  if pacman --config "$conf" -T 2>&1 | grep -q "not recognized"; then
    sed -i "/^$opt\$/d" "$conf"
    return 1
  fi
}
if [ "${PACMAN_DISABLE_SANDBOX:-0}" = 1 ]; then
  add_pacman_opt "$PROFILE/pacman.conf" DisableSandbox || {
    add_pacman_opt "$PROFILE/pacman.conf" DisableSandboxFilesystem || true
    add_pacman_opt "$PROFILE/pacman.conf" DisableSandboxSyscalls || true
  }
fi

if [ "$PROFILE_ONLY" = 1 ]; then
  say "Profile ready: $PROFILE"; exit 0
fi

# ------------------------------------------------------------------ 5. make the ISO
say "Building the ISO (this is the long part)"
sudo rm -rf "$BUILD/work"
mkdir -p "$OUT"
sudo mkarchiso -v -w "$BUILD/work" -o "$OUT" "$PROFILE"
sudo chown "$USER": "$OUT"/*.iso

ISO=$(ls -t "$OUT"/vespara-*.iso | head -1)
say "Done!"
echo "  ISO:    $ISO  ($(du -h "$ISO" | cut -f1))"
echo "  sha256: $(sha256sum "$ISO" | cut -d' ' -f1)"
echo
echo "Test it:   ./scripts/run-qemu.sh $ISO"
echo "Real PC:   write it to a USB stick with  sudo dd if=$ISO of=/dev/sdX bs=4M status=progress oflag=sync"
echo "           (double-check /dev/sdX: dd erases whatever you point it at)"
