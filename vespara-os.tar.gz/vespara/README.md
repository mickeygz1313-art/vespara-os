# Vespara OS

Arch Linux underneath. On top: a custom Wayland compositor (`vespara-wm`, C + wlroots 0.17)
and a custom shell (`vespara-shell`, HTML/CSS/JS in WebKit, attached through layer-shell).

    compositor/   window manager: borders, workspaces, layer-shell, IPC socket
    shell/        top bar, desktop (greeting + widgets + workspaces), dock, start menu,
                  vespara-settings (Settings app), vespara-greeter (login screen)
    shell/ui/     the actual UI: plain HTML/CSS/JS, edit and restart to see changes
    config/       default user config (copied to ~/.config/vespara on first login)
    session/      login session scripts
    scripts/      install-arch.sh, test-headless.sh

## Build the ISO
No Linux machine? `BUILD-IN-CLOUD.md`: GitHub builds it for you (free for public repos).

See `BUILD-ISO.md`:  `./build-iso.sh` on an Arch machine produces a bootable live + installer ISO.

## Install on an existing Arch system (no ISO)
    ./scripts/install-arch.sh
    # reboot, then on a TTY:
    vespara-session

## Keys (Alt is the modifier so it works inside VMs)
| Keys | Action |
|---|---|
| Alt+Enter | terminal (foot) |
| Alt+Space or Alt+D | start menu |
| Alt+Q | close window |
| Alt+Tab (hold Alt) | window switcher with previews, all workspaces. Tab / Shift+Tab to move, release Alt to switch, Esc cancels |
| Alt+F | maximize / restore |
| Alt+1..4 | switch workspace |
| Alt+Shift+1..4 | send window to workspace |
| Alt+left-drag / right-drag | move / resize window |
| Alt+L | lock the screen |
| Alt+N | notification center |
| Alt+A | quick settings |
| Volume / mute / mic / brightness keys | work anywhere, with an on-screen display |
| Print / Shift+Print | screenshot (full screen / pick an area) -> ~/Pictures/Screenshots |
| Alt+Shift+E | exit to TTY |

## Settings app
`vespara-settings [page]`  pages: network, bluetooth, sound, display, appearance, keyboard, datetime, profile, about.
Also opens from the dock gear, the start menu, and by clicking the volume/network/clock icons in the top bar.
Display changes show a 10 second "keep these settings?" countdown and revert on their own.

## Window switcher
Alt+Tab shows a snapshot card for every window (across all workspaces, most recent first). The compositor renders the
snapshots itself; the shell draws titles/icons on top. Test without a keyboard: `switch start|next|commit|cancel` on the socket.

## Screen off + idle
After no activity the screen turns off (Settings -> Lock Screen, default 15 min) and wakes on any key/mouse input.
Apps that hold an idle-inhibitor (Firefox/mpv playing video) keep the screen on and prevent auto-lock.

## Welcome app
`vespara-welcome` runs once at first login (and on every live-ISO boot): Wi-Fi, accent + wallpaper, keyboard layout,
shortcuts. On the live ISO it offers "Try Vespara OS" / "Install Vespara OS". Re-open: Settings -> About -> Welcome tour.

## Quick Settings
Click the status icons in the top bar (or Alt+A): Wi-Fi and Bluetooth (click the arrow to pick a network/device inline),
Do Not Disturb, Airplane mode, Night light, Power mode, Mic mute, Screenshot, volume + brightness sliders, battery, and
Settings / Lock / Power buttons. Tiles for hardware you don't have are hidden.
Night light uses `wlsunset` through the compositor's gamma-control protocol; Power mode needs `power-profiles-daemon`;
brightness goes through logind (no root needed). Preview with fake data: `VESPARA_QS_DEMO=1`.

## Lock screen
`vespara-lock` uses the `ext-session-lock` protocol: the compositor blanks every screen and sends all input to the
locker, so killing or crashing the locker does NOT unlock the session. Passwords are checked with PAM (`/etc/pam.d/vespara-lock`).
Triggers: Alt+L, Start -> Power -> Lock, idle timeout (Settings -> Lock Screen), going to sleep / closing the lid (via logind).

## Notifications
The shell is the notification daemon (`org.freedesktop.Notifications`): pop-ups top right, history + calendar in the
notification center (bell in the top bar, or Alt+N), Do Not Disturb, critical alerts always show. Test: `notify-send hi there`.

## Login screen
`greetd` runs `vespara-greeter-session` -> compositor -> `vespara-greeter`. The installer enables it if you say yes.
Preview it without greetd (inside a running Vespara session, from a TTY: `vespara-wm -s 'vespara-greeter --demo'`), password: demo.

## Customize (~/.config/vespara/)
- `config.json`: name, accent, clock24, keyboard, displays, weather location/units, workspace names, wallpapers (the Settings app edits this for you)
- `events.json`: `[{"time":"9:00 AM","title":"Standup","color":"#35d0ff"}]` for the Today widget
- `pinned.json`: dock/start pinned apps (see DEFAULT_PINNED in shell/vespara-shell)
- `notes.txt`: Quick Notes (saved automatically)

## How the pieces talk
- Shell/Settings -> compositor: unix socket `$XDG_RUNTIME_DIR/vespara.sock` (`state`, `workspace N`, `focus ID`, `close ID`, `move N`, `outputs`, `mode NAME W H MHZ`, `scale NAME S`, `accent RRGGBB`, `layout L [V]`, `idle SECONDS`, `blank SECONDS`, `dpms on|off`, `switch start|next|commit|cancel`, `quit`)
  Compositor also forwards keys to the shell: vol-up/down/mute, mic-mute, bright-up/down, screenshot[-region], toggle-quick.
- Compositor -> shell: `$XDG_RUNTIME_DIR/vespara-shell.sock` (`toggle-start`, `toggle-center`, `lock`, `reload-config`)
