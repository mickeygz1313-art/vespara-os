"""vespara_backend: the Settings/Welcome backend (everything the web pages can call).

Each function takes the page's argument dict and returns a JSON-able dict. METHODS maps
the "section.name" the page uses to the function. Shared by vespara-settings and vespara-welcome.
"""
import glob, json, os, platform, pwd, re, shutil, socket, subprocess, sys, threading, time

sys.path[:0] = [os.path.dirname(os.path.realpath(__file__)), "/usr/lib/vespara"]
from vespara_sys import sh, terse, parse_wifi, parse_bt_devices, parse_pactl, pct  # noqa: E402,F401
from gi.repository import Gio, GLib  # noqa: E402

HERE = os.path.dirname(os.path.realpath(__file__))
UI = next((d for d in (os.environ.get("VESPARA_UI"), os.path.join(HERE, "ui"),
                       "/usr/share/vespara/ui", "/usr/local/share/vespara/ui") if d and os.path.isdir(d)), None)
CFG_DIR = os.path.expanduser("~/.config/vespara")
CFG_FILE = os.path.join(CFG_DIR, "config.json")
RT = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
SOCK = os.path.join(RT, "vespara.sock")
SHELL_SOCK = os.path.join(RT, "vespara-shell.sock")


# ------------------------------------------------------------------ helpers
def sock_cmd(path, cmd):
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(path)
        s.sendall((cmd + "\n").encode())
        data = b""
        while True:
            c = s.recv(65536)
            if not c:
                break
            data += c
        s.close()
        return data.decode().strip()
    except Exception:
        return ""


def ipc(cmd):
    return sock_cmd(SOCK, cmd)


def load_cfg():
    try:
        with open(CFG_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(patch):
    cfg = load_cfg()
    cfg.update(patch)
    os.makedirs(CFG_DIR, exist_ok=True)
    tmp = CFG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CFG_FILE)
    sock_cmd(SHELL_SOCK, "reload-config")
    return cfg


def priv(cmd, terminal):
    """Run a privileged command: sudo without a prompt (works on the live ISO),
    otherwise open a terminal so the user can type their password."""
    rc, out = sh(["sudo", "-n"] + cmd)
    if rc == 0:
        return {"ok": True}
    quoted = " ".join("'%s'" % c.replace("'", "'\\''") for c in cmd)
    subprocess.Popen(["foot", "-e", "sh", "-c", "sudo %s; echo; read -r -p 'Done. Press Enter to close.' _" % quoted],
                     start_new_session=True)
    return {"ok": True, "terminal": True}


# ------------------------------------------------------------------ network
def wifi_status(_):
    rc, out = sh(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "dev", "status"])
    if rc != 0:
        return {"available": False, "error": out.strip()}
    devs = [dict(zip(("device", "type", "state", "connection"), terse(l))) for l in out.strip().splitlines()]
    rc, radio = sh(["nmcli", "radio", "wifi"])
    return {"available": True, "devices": [d for d in devs if d["type"] in ("wifi", "ethernet")],
            "wifi_enabled": radio.strip() == "enabled", "has_wifi": any(d["type"] == "wifi" for d in devs)}


def wifi_list(a):
    sh(["nmcli", "dev", "wifi", "rescan"], timeout=8)
    rc, saved = sh(["nmcli", "-t", "-f", "NAME,TYPE", "con", "show"])
    names = {terse(l)[0] for l in saved.splitlines() if "wireless" in l}
    rc, out = sh(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list"])
    return {"networks": parse_wifi(out, names) if rc == 0 else [], "error": "" if rc == 0 else out.strip()}


def wifi_connect(a):
    ssid, pw = a["ssid"], a.get("password")
    if a.get("saved") and not pw:
        rc, out = sh(["nmcli", "con", "up", "id", ssid], timeout=40)
    else:
        cmd = ["nmcli", "dev", "wifi", "connect", ssid] + (["password", pw] if pw else [])
        rc, out = sh(cmd, timeout=40)
    return {"ok": rc == 0, "message": out.strip()}


def wifi_disconnect(a):
    rc, out = sh(["nmcli", "con", "down", "id", a["ssid"]])
    return {"ok": rc == 0, "message": out.strip()}


def wifi_forget(a):
    rc, out = sh(["nmcli", "con", "delete", "id", a["ssid"]])
    return {"ok": rc == 0, "message": out.strip()}


def wifi_radio(a):
    rc, out = sh(["nmcli", "radio", "wifi", "on" if a["on"] else "off"])
    return {"ok": rc == 0}


# ------------------------------------------------------------------ bluetooth
def bt_status(_):
    rc, out = sh(["bluetoothctl", "show"])
    if rc != 0 or "Controller" not in out:
        return {"available": False}
    return {"available": True, "powered": "Powered: yes" in out}


def bt_devices(a):
    rc, out = sh(["bluetoothctl", "devices"])
    devs = parse_bt_devices(out)
    for d in devs:
        rc, info = sh(["bluetoothctl", "info", d["mac"]])
        d["connected"] = "Connected: yes" in info
        d["paired"] = "Paired: yes" in info
    devs.sort(key=lambda d: (not d["connected"], not d["paired"], d["name"].lower()))
    return {"devices": devs}


def bt_power(a):
    if a["on"]:
        sh(["rfkill", "unblock", "bluetooth"])
    rc, out = sh(["bluetoothctl", "power", "on" if a["on"] else "off"])
    return {"ok": rc == 0}


def bt_scan(a):
    sh(["bluetoothctl", "--timeout", "8", "scan", "on"], timeout=15)
    return bt_devices(a)


def bt_connect(a):
    sh(["bluetoothctl", "pair", a["mac"]], timeout=25)
    sh(["bluetoothctl", "trust", a["mac"]])
    rc, out = sh(["bluetoothctl", "connect", a["mac"]], timeout=25)
    return {"ok": rc == 0 and "successful" in out.lower(), "message": out.strip().splitlines()[-1] if out.strip() else ""}


def bt_disconnect(a):
    rc, out = sh(["bluetoothctl", "disconnect", a["mac"]])
    return {"ok": rc == 0}


def bt_remove(a):
    rc, out = sh(["bluetoothctl", "remove", a["mac"]])
    return {"ok": rc == 0}


# ------------------------------------------------------------------ sound
def snd_get(_):
    rc, out = sh(["pactl", "--format=json", "list", "sinks"])
    if rc != 0:
        return {"available": False, "error": out.strip()}
    sinks = parse_pactl(out, "sink")
    rc, out = sh(["pactl", "--format=json", "list", "sources"])
    sources = parse_pactl(out, "source")
    return {"available": True, "sinks": sinks, "sources": sources,
            "default_sink": sh(["pactl", "get-default-sink"])[1].strip(),
            "default_source": sh(["pactl", "get-default-source"])[1].strip()}


def snd_volume(a):
    sh(["pactl", "set-%s-volume" % a["kind"], a["name"], "%d%%" % max(0, min(150, int(a["value"])))])
    return {"ok": True}


def snd_mute(a):
    sh(["pactl", "set-%s-mute" % a["kind"], a["name"], "1" if a["mute"] else "0"])
    return {"ok": True}


def snd_default(a):
    sh(["pactl", "set-default-%s" % a["kind"], a["name"]])
    return {"ok": True}


# ------------------------------------------------------------------ display
def disp_get(_):
    raw = ipc("outputs")
    try:
        outs = json.loads(raw)
    except ValueError:
        outs = []
    return {"outputs": outs, "saved": load_cfg().get("displays", {})}


def disp_set(a):
    name = a["name"]
    ok = True
    if a.get("w"):
        ok = ipc("mode %s %d %d %d" % (name, a["w"], a["h"], a.get("r", 0))) == "ok"
    if ok and a.get("scale"):
        ok = ipc("scale %s %s" % (name, a["scale"])) == "ok"
    return {"ok": ok}


def disp_save(a):
    d = load_cfg().get("displays", {})
    d[a["name"]] = {k: a[k] for k in ("w", "h", "r", "scale") if k in a}
    save_cfg({"displays": d})
    return {"ok": True}


# ------------------------------------------------------------------ appearance / config
def cfg_get(_):
    user = pwd.getpwuid(os.getuid())
    full = user.pw_gecos.split(",")[0] or user.pw_name
    return {"config": load_cfg(), "user": user.pw_name, "fullname": full}


def cfg_set(a):
    cfg = save_cfg(a["patch"])
    if "accent" in a["patch"]:
        ipc("accent " + cfg["accent"].lstrip("#"))
    if "keyboard" in a["patch"]:
        k = cfg["keyboard"]
        ipc("layout %s %s" % (k.get("layout", "us"), k.get("variant", "")))
    return {"ok": True}


def wall_list(_):
    built = [{"id": "builtin:" + os.path.basename(p), "path": p, "name": {"work": "Mountain Lake"}.get(os.path.splitext(os.path.basename(p))[0], os.path.splitext(os.path.basename(p))[0].title())}
             for p in sorted(glob.glob(os.path.join(UI, "wallpapers", "*.svg")))]
    pics = []
    for d in ("~/Pictures", "~/Pictures/Wallpapers", "/usr/share/backgrounds"):
        for p in sorted(glob.glob(os.path.join(os.path.expanduser(d), "*"))):
            if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                pics.append({"id": p, "path": p, "name": os.path.basename(p)})
    return {"builtin": built, "pictures": pics[:60]}


def parse_xkb_lst(text):
    layouts, variants, sec = [], {}, None
    for line in text.splitlines():
        if line.startswith("! "):
            sec = line[2:].strip()
        elif sec == "layout" and line.strip():
            code, _, desc = line.strip().partition(" ")
            layouts.append({"code": code, "name": desc.strip()})
        elif sec == "variant" and line.strip():
            code, _, rest = line.strip().partition(" ")
            lay, _, desc = rest.strip().partition(": ")
            variants.setdefault(lay, []).append({"code": code, "name": desc})
    return layouts, variants


def kb_layouts(_):
    for p in ("/usr/share/X11/xkb/rules/base.lst", "/usr/share/X11/xkb/rules/evdev.lst"):
        try:
            with open(p) as f:
                l, v = parse_xkb_lst(f.read())
            if l:
                return {"layouts": l, "variants": v}
        except OSError:
            pass
    return {"layouts": [{"code": "us", "name": "English (US)"}], "variants": {}}


# ------------------------------------------------------------------ date & time
def time_get(_):
    rc, out = sh(["timedatectl", "show"])
    props = dict(l.split("=", 1) for l in out.splitlines() if "=" in l)
    return {"timezone": props.get("Timezone", ""), "ntp": props.get("NTP") == "yes", "ok": rc == 0}


def time_zones(_):
    rc, out = sh(["timedatectl", "list-timezones"])
    return {"zones": out.split() if rc == 0 else []}


def time_set(a):
    if not re.fullmatch(r"[A-Za-z0-9_+/-]+", a["tz"]):
        return {"ok": False}
    return priv(["timedatectl", "set-timezone", a["tz"]], True)


def time_ntp(a):
    return priv(["timedatectl", "set-ntp", "true" if a["on"] else "false"], True)


# ------------------------------------------------------------------ about / misc
def about_get(_):
    osr = {}
    try:
        with open("/etc/os-release") as f:
            osr = dict(l.strip().split("=", 1) for l in f if "=" in l)
    except OSError:
        pass
    cpu = ""
    try:
        with open("/proc/cpuinfo") as f:
            cpu = next((l.split(":", 1)[1].strip() for l in f if l.startswith("model name")), "")
    except OSError:
        pass
    mem = 0
    try:
        with open("/proc/meminfo") as f:
            mem = int(next(l for l in f if l.startswith("MemTotal")).split()[1]) * 1024
    except Exception:
        pass
    du = shutil.disk_usage("/")
    try:
        with open("/proc/uptime") as f:
            up = int(float(f.read().split()[0]))
    except OSError:
        up = 0
    return {"os": osr.get("PRETTY_NAME", "Vespara OS").strip('"'), "kernel": platform.release(), "host": platform.node(),
            "cpu": cpu, "mem": mem, "disk_total": du.total, "disk_free": du.free, "uptime": up,
            "session": os.environ.get("XDG_SESSION_TYPE", "wayland"), "user": pwd.getpwuid(os.getuid()).pw_name}


def run_terminal(a):
    cmds = {"passwd": ["foot", "-e", "passwd"], "welcome": ["vespara-welcome"],
            "update": ["foot", "-e", "sh", "-c", "sudo pacman -Syu; echo; read -r -p 'Press Enter to close.' _"]}
    if a["what"] in cmds:
        subprocess.Popen(cmds[a["what"]], start_new_session=True)
    return {"ok": True}


def notify_test(_):
    bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    bus.call_sync("org.freedesktop.Notifications", "/org/freedesktop/Notifications", "org.freedesktop.Notifications", "Notify",
                  GLib.Variant("(susssasa{sv}i)", ("Settings", 0, "preferences-system", "Test notification",
                                                   "This is what notifications look like on Vespara OS.", [], {}, -1)),
                  GLib.VariantType("(u)"), Gio.DBusCallFlags.NONE, 2000, None)
    return {"ok": True}


def lock_now(_):
    subprocess.Popen(["vespara-lock"], start_new_session=True)
    return {"ok": True}


METHODS = {
    "cfg.get": cfg_get, "cfg.set": cfg_set, "wall.list": wall_list,
    "wifi.status": wifi_status, "wifi.list": wifi_list, "wifi.connect": wifi_connect, "wifi.disconnect": wifi_disconnect,
    "wifi.forget": wifi_forget, "wifi.radio": wifi_radio,
    "bt.status": bt_status, "bt.devices": bt_devices, "bt.power": bt_power, "bt.scan": bt_scan,
    "bt.connect": bt_connect, "bt.disconnect": bt_disconnect, "bt.remove": bt_remove,
    "snd.get": snd_get, "snd.volume": snd_volume, "snd.mute": snd_mute, "snd.default": snd_default,
    "disp.get": disp_get, "disp.set": disp_set, "disp.save": disp_save,
    "kb.layouts": kb_layouts, "time.get": time_get, "time.zones": time_zones, "time.set": time_set, "time.ntp": time_ntp,
    "about.get": about_get, "terminal": run_terminal, "notify.test": notify_test, "lock.now": lock_now,
}
