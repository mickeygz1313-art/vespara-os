"""vespara_sys: system helpers shared by vespara-shell (Quick Settings) and vespara-settings.

Everything shells out to the standard tools (nmcli, bluetoothctl, pactl, rfkill,
powerprofilesctl, logind) and returns plain dicts. Every function degrades to
"not available" instead of raising, so a missing service never breaks the UI.
"""
import glob
import json
import os
import re
import shutil
import subprocess


# ------------------------------------------------------------------ plumbing
def sh(cmd, timeout=20, inp=None):
    """Run a command list, return (returncode, stdout+stderr)."""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=inp)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, "%s: command not found" % cmd[0]
    except subprocess.TimeoutExpired:
        return 124, "timed out"


def terse(line):
    """Split an nmcli -t line on unescaped ':' and unescape the fields."""
    return [f.replace("\\:", ":").replace("\\\\", "\\") for f in re.split(r"(?<!\\):", line)]


# ------------------------------------------------------------------ Wi-Fi
def parse_wifi(out, saved):
    best = {}
    for line in out.strip().splitlines():
        f = terse(line)
        if len(f) < 4 or not f[1]:
            continue
        inuse, ssid, sig, sec = f[0] == "*", f[1], int(f[2] or 0), f[3]
        cur = best.get(ssid)
        if not cur or sig > cur["signal"] or inuse:
            best[ssid] = {"ssid": ssid, "signal": sig, "secure": bool(sec and sec != "--"),
                          "active": inuse or (cur or {}).get("active", False), "saved": ssid in saved}
    return sorted(best.values(), key=lambda n: (not n["active"], -n["signal"]))


def wifi_networks(rescan=True):
    if rescan:
        sh(["nmcli", "dev", "wifi", "rescan"], timeout=8)
    rc, saved = sh(["nmcli", "-t", "-f", "NAME,TYPE", "con", "show"])
    names = {terse(l)[0] for l in saved.splitlines() if "wireless" in l}
    rc, out = sh(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list"])
    return {"networks": parse_wifi(out, names) if rc == 0 else [], "error": "" if rc == 0 else out.strip()}


def wifi_summary():
    rc, radio = sh(["nmcli", "radio", "wifi"])
    if rc != 0:
        return {"available": False}
    rc, dev = sh(["nmcli", "-t", "-f", "TYPE", "dev", "status"])
    if "wifi" not in dev:
        return {"available": False}
    enabled = radio.strip() == "enabled"
    ssid, signal = None, 0
    if enabled:
        rc, out = sh(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL", "dev", "wifi", "list"])
        for line in out.splitlines():
            f = terse(line)
            if len(f) >= 3 and f[0] == "*":
                ssid, signal = f[1], int(f[2] or 0)
                break
    return {"available": True, "enabled": enabled, "ssid": ssid, "signal": signal}


def wifi_set(on):
    return sh(["nmcli", "radio", "wifi", "on" if on else "off"])[0] == 0


def wifi_connect(ssid, password=None, saved=False):
    if saved and not password:
        rc, out = sh(["nmcli", "con", "up", "id", ssid], timeout=40)
    else:
        rc, out = sh(["nmcli", "dev", "wifi", "connect", ssid] + (["password", password] if password else []), timeout=40)
    return {"ok": rc == 0, "message": out.strip()}


# ------------------------------------------------------------------ Bluetooth
def parse_bt_devices(out):
    return [{"mac": m.group(1), "name": m.group(2)} for m in re.finditer(r"^Device ([0-9A-F:]{17}) (.+)$", out, re.M)]


def bt_summary():
    rc, out = sh(["bluetoothctl", "show"])
    if rc != 0 or "Controller" not in out:
        return {"available": False}
    powered = "Powered: yes" in out
    connected = []
    if powered:
        rc, o = sh(["bluetoothctl", "devices", "Connected"])
        connected = [d["name"] for d in parse_bt_devices(o)] if rc == 0 else []
    return {"available": True, "powered": powered, "connected": connected}


def bt_set(on):
    if on:
        sh(["rfkill", "unblock", "bluetooth"])
    return sh(["bluetoothctl", "power", "on" if on else "off"])[0] == 0


def bt_device_list():
    rc, out = sh(["bluetoothctl", "devices"])
    devs = parse_bt_devices(out)
    for d in devs:
        rc, info = sh(["bluetoothctl", "info", d["mac"]])
        d["connected"] = "Connected: yes" in info
        d["paired"] = "Paired: yes" in info
    devs.sort(key=lambda d: (not d["connected"], not d["paired"], d["name"].lower()))
    return devs


# ------------------------------------------------------------------ sound (PulseAudio / PipeWire via pactl)
def pct(dev):
    try:
        v = next(iter(dev["volume"].values()))
        return int(v["value_percent"].rstrip("%"))
    except Exception:
        return 0


def parse_pactl(out, kind):
    try:
        items = json.loads(out)
    except ValueError:
        return []
    return [{"name": d["name"], "desc": d.get("description", d["name"]), "volume": pct(d), "mute": bool(d.get("mute"))}
            for d in items if not (kind == "source" and d["name"].endswith(".monitor"))]


def snd_default(kind):
    """State of the default sink ('sink') or source ('source')."""
    rc, name = sh(["pactl", "get-default-" + kind])
    if rc != 0:
        return {"available": False}
    name = name.strip()
    rc, out = sh(["pactl", "--format=json", "list", kind + "s"])
    for d in parse_pactl(out, kind):
        if d["name"] == name:
            return {"available": True, **d}
    return {"available": False}


def snd_volume(kind, percent):
    percent = max(0, min(150, int(percent)))
    return sh(["pactl", "set-%s-volume" % kind, "@DEFAULT_%s@" % kind.upper(), "%d%%" % percent])[0] == 0


def snd_mute(kind, mute=None):
    """mute=True/False sets it, None toggles."""
    arg = "toggle" if mute is None else ("1" if mute else "0")
    return sh(["pactl", "set-%s-mute" % kind, "@DEFAULT_%s@" % kind.upper(), arg])[0] == 0


# ------------------------------------------------------------------ brightness
def backlight_device():
    devs = sorted(glob.glob("/sys/class/backlight/*"))
    return devs[0] if devs else None


def backlight_get():
    dev = backlight_device()
    if not dev:
        return {"available": False}
    try:
        cur = int(open(dev + "/brightness").read())
        mx = int(open(dev + "/max_brightness").read())
        return {"available": True, "value": round(100 * cur / mx) if mx else 0, "name": os.path.basename(dev), "max": mx}
    except (OSError, ValueError):
        return {"available": False}


def backlight_set(percent):
    """Set via logind (works for the active session user, no root needed)."""
    b = backlight_get()
    if not b["available"]:
        return False
    raw = max(1, round(b["max"] * max(3, min(100, percent)) / 100))
    try:
        from gi.repository import Gio, GLib
        bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        bus.call_sync("org.freedesktop.login1", "/org/freedesktop/login1/session/auto",
                      "org.freedesktop.login1.Session", "SetBrightness",
                      GLib.Variant("(ssu)", ("backlight", b["name"], raw)), None, Gio.DBusCallFlags.NONE, 2000, None)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ airplane mode
def airplane_get():
    rc, out = sh(["rfkill", "-J"])
    if rc != 0:
        return None
    try:
        devs = json.loads(out)["rfkilldevices"]
    except (ValueError, KeyError):
        return None
    return bool(devs) and all(d.get("soft") == "blocked" or d.get("hard") == "blocked" for d in devs)


def airplane_set(on):
    return sh(["rfkill", "block" if on else "unblock", "all"])[0] == 0


# ------------------------------------------------------------------ power profile
def profile_get():
    rc, cur = sh(["powerprofilesctl", "get"])
    if rc != 0:
        return None
    rc, lst = sh(["powerprofilesctl", "list"])
    names = re.findall(r"^[* ]\s*([a-z-]+):", lst, re.M)
    return {"current": cur.strip(), "available": names or ["power-saver", "balanced", "performance"]}


def profile_set(name):
    return sh(["powerprofilesctl", "set", name])[0] == 0


# ------------------------------------------------------------------ night light (wlsunset holds the gamma ramp)
def night_available():
    return shutil.which("wlsunset") is not None


def night_start(temp=4000):
    """Constant colour temperature: wlsunset with equal day/night temps."""
    return subprocess.Popen(["wlsunset", "-t", str(int(temp)), "-T", str(int(temp)), "-S", "06:00", "-s", "18:00"],
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            start_new_session=True)


# ------------------------------------------------------------------ battery
def battery():
    for b in sorted(glob.glob("/sys/class/power_supply/*")):
        try:
            if open(b + "/type").read().strip() != "Battery":
                continue
            cap = int(open(b + "/capacity").read())
            status = open(b + "/status").read().strip()
            return {"pct": cap, "charging": status in ("Charging", "Full"), "status": status}
        except (OSError, ValueError):
            continue
    return None
