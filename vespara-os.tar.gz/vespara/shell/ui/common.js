const P={
 globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.4 3.4 3.4 14.6 0 18M12 3c-3.4 3.4-3.4 14.6 0 18"/>',
 folder:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
 terminal:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M7 10l3 2.5L7 15M12.5 15H17"/>',
 edit:'<path d="M4 20l1-4L16.5 4.5a2 2 0 0 1 3 3L8 19z"/><path d="M14 7l3 3"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
 grid:'<rect x="4" y="4" width="6.5" height="6.5" rx="1.6" fill="currentColor"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6" fill="currentColor"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6" fill="currentColor"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6" fill="currentColor"/>',
 apps:'<rect x="4" y="4" width="6" height="6" rx="1.4"/><rect x="14" y="4" width="6" height="6" rx="1.4"/><rect x="4" y="14" width="6" height="6" rx="1.4"/><rect x="14" y="14" width="6" height="6" rx="1.4"/>',
 home:'<path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z" fill="currentColor"/>',
 doc:'<path d="M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v4h4"/>',
 power:'<path d="M12 3v8"/><path d="M6.6 6.6a8 8 0 1 0 10.8 0"/>',
 search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
 wifi:'<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.8 16a5 5 0 0 1 6.4 0"/><circle cx="12" cy="19.3" r="1" fill="currentColor"/>',
 eth:'<rect x="4" y="5" width="16" height="10" rx="2"/><path d="M8 15v4M12 15v4M16 15v4M8 9v2M12 9v2M16 9v2"/>',
 bt:'<path d="M7 7l10 10-5 4V3l5 4L7 17"/>',
 trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
 chev:'<path d="M9 6l6 6-6 6"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 pc:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
 image:'<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M4 18l5-5 4 4 3-3 4 4"/>',
 vol:'<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
 cal:'<rect x="4" y="5" width="16" height="15" rx="2.5"/><path d="M4 10h16M9 3v4M15 3v4"/>',
 hour:'<path d="M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9s8 4 8 9"/>',
 lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
 moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
 out:'<path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4M15 8l4 4-4 4M19 12H9"/>',
 kb:'<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
 user:'<circle cx="12" cy="8.5" r="3.6"/><path d="M5 20c.6-3.6 3.6-5.6 7-5.6s6.4 2 7 5.6"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.01"/>',
 brush:'<path d="M14 4l6 6-8 8H6v-6zM6 18c-1 .8-1.6 2-2 3 2 0 3.5-.5 4-1.5"/>',
 bell:'<path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21a2 2 0 0 0 4 0"/>',
 bellOff:'<path d="M6 17V11a6 6 0 0 1 9-5.2M18 11v6l1.5 2H8M10 21a2 2 0 0 0 4 0M4 4l16 16"/>',
 volMute:'<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
 mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>',
 micOff:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M4 4l16 16"/>',
 plane:'<path d="M3 13l8-3V4.5a1.5 1.5 0 0 1 3 0V10l8 3v2l-8-1.5V19l2.5 1.5V22L12.5 21 8 22v-1.5L10.5 19v-5.5L3 15z"/>',
 bolt:'<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>',
 camera:'<path d="M4 8h3l1.5-2.5h7L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.6"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6L7 7M17 17l1.4 1.4M18.4 5.6L17 7M7 17l-1.4 1.4"/>',
 battery:'<rect x="3" y="7" width="16" height="10" rx="2.5"/><path d="M21 10.5v3M6.5 10.5v3M10 10.5v3"/>',
 plug:'<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0zM12 17v4"/>',
 down:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
 redo:'<path d="M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5"/>',
};
const ic=(n,s)=>`<svg class="i" viewBox="0 0 24 24"${s?` style="font-size:${s}px"`:''}>${P[n]||P.apps}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const GRAD=[['#4aa8ff','#2d6bff'],['#ffd36b','#ff9d2e'],['#47d49a','#1e9e6a'],['#ff7a8a','#d93c64'],['#b58cff','#6f4de0'],['#6fd3ff','#3b8fe8'],['#8a94b8','#4a5378']];
function tile(a,size){
  const st=`width:${size}px;height:${size}px;`;
  if(a.icon) return `<span class="tile" style="${st}background:rgba(255,255,255,.07)"><img src="file://${esc(a.icon)}" draggable="false"></span>`;
  const g=a.color||GRAD[[...(a.name||'?')].reduce((h,c)=>h+c.charCodeAt(0),0)%GRAD.length];
  const inner=a.glyph?ic(a.glyph,size*.52):`<b style="font-size:${size*.46}px">${esc((a.name||'?')[0].toUpperCase())}</b>`;
  return `<span class="tile" style="${st}background:linear-gradient(145deg,${g[0]},${g[1]})">${inner}</span>`;
}
const V={h:{},last:{},on(k,f){(V.h[k]=V.h[k]||[]).push(f);if(k in V.last)f(V.last[k])},
  send(o){try{webkit.messageHandlers.vespara.postMessage(JSON.stringify(o))}catch(e){}}};
window.vespara={push(k,d){V.last[k]=d;(V.h[k]||[]).forEach(f=>f(d))}};
const fmtTime=()=>new Date().toLocaleTimeString('en-US',{hour:V.clock24?'2-digit':'numeric',minute:'2-digit',hour12:!V.clock24});
const fmtDate=()=>new Date().toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
function matches(appId,a){const x=(appId||'').toLowerCase();if(!x)return false;
  return (a.keys||[]).some(k=>k&&(k===x||x.includes(k)||(k.length>3&&k.includes(x))));}
function ago(ts){const s=Date.now()/1000-ts;if(s<3600)return Math.max(1,Math.round(s/60))+'m ago';
  if(s<86400)return Math.round(s/3600)+'h ago';if(s<172800)return 'Yesterday';return Math.round(s/86400)+'d ago';}

V.on('config',c=>{document.documentElement.style.setProperty('--accent',c.accent||'#5b9bff');V.clock24=!!c.clock24;if(window.tick)tick()});

const pretty=s=>{const p=String(s||'App').split('.').pop().replace(/[-_]/g,' ');return p.charAt(0).toUpperCase()+p.slice(1)};
