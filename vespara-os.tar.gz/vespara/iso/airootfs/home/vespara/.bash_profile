# Live session: start the Vespara desktop on the first text console.
# If it ever exits or crashes you simply land in this shell.
[ -f ~/.bashrc ] && . ~/.bashrc
if [ -z "${WAYLAND_DISPLAY:-}" ] && [ "$(tty)" = /dev/tty1 ]; then
  vespara-session
fi
