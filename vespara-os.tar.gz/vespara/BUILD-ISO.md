# Building the Vespara OS ISO

You need an **Arch Linux** machine to build it (a VM is fine, mkarchiso only runs on Arch):

- 4 GB RAM, 25 GB disk (12 GB free for the build), internet
- a normal user with `sudo` (do NOT build as root)

```bash
tar xzf vespara-os.tar.gz && cd vespara
./build-iso.sh
```

20-40 minutes later: `out/vespara-YYYY.MM.DD-x86_64.iso`

What the script does
1. checks every package name exists in the Arch repos (stops early with a list if Arch renamed one)
2. builds 3 pacman packages: `wlroots-vespara` (pinned 0.17.4), `vespara-desktop`, `vespara-installer`
3. puts them in a local repo and copies the archiso "releng" profile, rebrands it, adds the live user
   (autologin into the desktop), NetworkManager, the installer and the repo
4. runs `mkarchiso`

If gitlab.freedesktop.org is blocked for you: download
`https://gitlab.freedesktop.org/wlroots/wlroots/-/archive/0.17.4/wlroots-0.17.4.tar.gz`
and drop it in `packaging/wlroots-vespara/` before running the script.

## Try it
    sudo pacman -S qemu-desktop            # on the build machine
    ./scripts/run-qemu.sh out/vespara-*.iso --install     # live boot + blank disk to install onto
    # UEFI test: add --uefi (needs edk2-ovmf)

Live session = log in automatically as `vespara`, desktop starts. Dock -> "Install Vespara OS"
(or `sudo vespara-install` in a terminal) installs it to a disk.

Real PC: `sudo dd if=out/vespara-*.iso of=/dev/sdX bs=4M status=progress oflag=sync`
(check /dev/sdX twice; dd erases whatever you point it at).

## Installer
Text mode, with a choice of graphical login screen (default) or text login that starts the desktop. Erases ONE whole disk (UEFI: GPT + 512M ESP + ext4, BIOS: GPT + bios_boot + ext4),
GRUB, NetworkManager, a user with sudo, root locked. Needs internet (downloads packages).
Preview without touching anything: `DRY_RUN=1 vespara-install`

## Live session
The live ISO logs in automatically (no login screen). To see the login screen, install to a disk (or run `vespara-greeter --demo`).
Settings: dock gear icon. On the live ISO, privileged settings (time zone) work without a password.

## First boot
The live ISO opens the welcome screen (Try / Install) automatically. After installing, the first login runs the full welcome tour.

## Lock screen on the live ISO
The live user has no password, so there the lock screen unlocks with any password (press Enter). On an installed system it checks your real password.

## If the desktop doesn't come up in the live session
You land in a normal shell on tty1. Run `vespara-session` to see the error, and send it to me.
Virtual machines automatically use software rendering (see session/vespara-session).
