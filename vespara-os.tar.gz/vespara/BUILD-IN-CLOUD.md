# Build the Vespara OS ISO in the cloud (no Linux machine needed)

GitHub will build the ISO for you on its own servers, inside an Arch Linux container. It's free for **public** repositories.
You only need a web browser. The finished ISO appears as a download on GitHub.

## One-time setup (about 10 minutes)

1. **Make a GitHub account** at github.com (free).
2. **Create a repository**: click **+ → New repository**. Name it `vespara-os`. Choose **Public**. Click *Create repository*.
   *(Public matters: builds are free for public repos. A private free account only gets 500 MB of artifact storage, too small for an ISO.)*
3. **Upload the project**: on the new repo page click **uploading an existing file**, drag `vespara-os.tar.gz` in
   (just that one file, don't unzip it), and click **Commit changes**.
4. **Add the build recipe**: click **Add file → Create new file**.
   In the file-name box type exactly `.github/workflows/build-iso.yml` (typing `/` creates the folders).
   Open the `build-iso.yml` file I gave you in any text editor, copy everything, paste it into the big box, click **Commit changes**.

## Build the ISO

1. Click the **Actions** tab. If GitHub asks, click the green button to enable workflows.
2. Click **Build Vespara OS ISO** (left side), then **Run workflow**. Leave "publish as Release" ticked, click the green **Run workflow**.
3. Wait. A build probably takes somewhere around 30 to 60 minutes. Click the running job to watch the log.

## Download it

- **Easiest:** go back to the repo's main page. On the right, click **Releases** → the newest one → download the `.iso`
  (and the `.sha256` checksum file).
  - If you see several files ending in `.part00`, `.part01`: GitHub limits each file to under 2 GiB, so the ISO was split.
    Join them (instructions are in `HOW-TO-JOIN.txt` in the same release):
    Windows (Command Prompt, in the download folder): `copy /b vespara-xxxx.iso.part00 + vespara-xxxx.iso.part01 vespara.iso`
    Linux/macOS: `cat vespara-*.iso.part* > vespara.iso`
- **Alternative:** open the finished run → **Artifacts** → `vespara-os-iso` (a .zip containing the ISO; kept for 7 days).

## Check it, then try it

1. Compare the SHA-256 of the ISO with the `.sha256` file (Windows: `certutil -hashfile vespara.iso SHA256`).
2. **Try it in a virtual machine first** (VirtualBox or QEMU): type: Linux, Arch Linux 64-bit, 4 GB RAM, 20 GB disk,
   enable EFI if you like, boot from the ISO. You should land on the Vespara welcome screen.
3. For a real PC: write the ISO to a USB stick with **Rufus (choose DD Image mode)**, **balenaEtcher** or **Ventoy**.
   Only install onto a real disk after the VM test works. The installer erases the disk you choose.

## If the build fails

Click the failed run, click the step with the red ✗, copy the **last 50 lines** of its log and send them to me.
Likely causes: Arch renamed a package (the build lists the missing names), or a download hiccup (just click **Re-run jobs**).

## Updating later

Replace `vespara-os.tar.gz` in the repo (**Add file → Upload files**, same name) and run the workflow again.

## Good to know

- Nobody, including me, has run this exact workflow yet, so the first run may need one round of fixes.
- Public repository = anyone can see your files and download the ISO. That's fine here: it's your own OS project.
