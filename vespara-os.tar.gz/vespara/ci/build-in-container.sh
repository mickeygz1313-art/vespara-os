#!/bin/bash
# Runs INSIDE an Arch Linux container, as root. Called by .github/workflows/build-iso.yml.
# It prepares Arch, then runs the normal ./build-iso.sh as an unprivileged user.
set -euxo pipefail
cd /work

# Add a pacman.conf [options] directive only if this pacman version understands it.
add_opt() {
  local conf=$1 opt=$2
  sed -i "/^\[options\]/a $opt" "$conf"
  # pacman only WARNS about unknown directives (and exits 0), so look for the warning
  if pacman --config "$conf" -T 2>&1 | grep -q "not recognized"; then
    sed -i "/^$opt\$/d" "$conf"
    return 1
  fi
}
# pacman >= 7 sandboxes downloads with Landlock, which can fail inside containers.
add_opt /etc/pacman.conf DisableSandbox || {
  add_opt /etc/pacman.conf DisableSandboxFilesystem || true
  add_opt /etc/pacman.conf DisableSandboxSyscalls || true
}

pacman-key --init
pacman-key --populate archlinux
pacman -Syu --noconfirm --needed sudo base-devel git archiso

# makepkg and build-iso.sh refuse to run as root.
id builder >/dev/null 2>&1 || useradd -m builder
echo 'builder ALL=(ALL) NOPASSWD: ALL' > /etc/sudoers.d/builder
chmod 440 /etc/sudoers.d/builder
chown -R builder:builder /work

sudo -u builder -H env PACMAN_DISABLE_SANDBOX=1 CI=1 bash -c 'cd /work && ./build-iso.sh'

# let the host runner read/delete everything we made
chmod -R a+rwX /work
ls -lh /work/out
