/*
 * vespara-wm: the Vespara OS compositor.
 *
 * Built on wlroots 0.17 (pinned on purpose: the wlroots API changes every
 * release, so scripts/setup-arch.sh builds exactly 0.17.x for you).
 *
 * Derived from tinywl (public domain / CC0), extended with:
 *   - window borders (focused / unfocused colors)
 *   - Alt+drag to move, Alt+right-drag to resize
 *   - keybinds (see handle_keybinding)
 *   - wlr-layer-shell  -> taskbar, launcher, wallpaper clients
 *   - wlr-foreign-toplevel -> taskbar can list/focus/close windows
 *   - maximize toggle
 *   - autostart command (-s)
 */
#define _GNU_SOURCE
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <wayland-server-core.h>
#include <wlr/backend.h>
#include <wlr/render/allocator.h>
#include <wlr/render/drm_format_set.h>
#include <wlr/render/pass.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_cursor.h>
#include <wlr/types/wlr_data_device.h>
#include <wlr/types/wlr_foreign_toplevel_management_v1.h>
#include <wlr/types/wlr_gamma_control_v1.h>
#include <wlr/types/wlr_idle_inhibit_v1.h>
#include <wlr/types/wlr_input_device.h>
#include <wlr/types/wlr_keyboard.h>
#include <wlr/types/wlr_layer_shell_v1.h>
#include <wlr/types/wlr_output.h>
#include <wlr/types/wlr_output_layout.h>
#include <wlr/types/wlr_pointer.h>
#include <wlr/types/wlr_primary_selection_v1.h>
#include <wlr/types/wlr_xdg_output_v1.h>
#include <wlr/types/wlr_scene.h>
#include <wlr/types/wlr_screencopy_v1.h>
#include <wlr/types/wlr_session_lock_v1.h>
#include <wlr/types/wlr_seat.h>
#include <wlr/types/wlr_subcompositor.h>
#include <wlr/types/wlr_xcursor_manager.h>
#include <wlr/types/wlr_xdg_shell.h>
#include <wlr/util/log.h>
#include <xkbcommon/xkbcommon.h>

#define BORDER 2
#define MIN_SIZE 120
#define NUM_WS 4
#define MK_ARGB8888 0x34325241u /* DRM_FORMAT_ARGB8888 */

/* Alt+Tab switcher card geometry (logical px) */
#define SW_CW 232
#define SW_CH 176
#define SW_GAP 18
#define SW_TW 208
#define SW_TH 120

static const float COLOR_BG[4]        = {0.06f, 0.09f, 0.16f, 1.0f};
static const float COLOR_BLACK[4] = {0.0f, 0.0f, 0.0f, 1.0f};
static float COLOR_FOCUSED[4]   = {0.36f, 0.62f, 1.00f, 1.0f};
static const float COLOR_UNFOCUSED[4] = {0.20f, 0.21f, 0.28f, 1.0f};

/* Change these to taste. */
static const char *TERMINAL = "foot";

enum cursor_mode { CURSOR_PASSTHROUGH, CURSOR_MOVE, CURSOR_RESIZE };

struct mk_server {
	struct wl_display *display;
	struct wlr_backend *backend;
	struct wlr_renderer *renderer;
	struct wlr_allocator *allocator;
	struct wlr_scene *scene;
	struct wlr_scene_output_layout *scene_layout;

	/* z-order, bottom to top */
	struct wlr_scene_tree *tree_bg;      /* our own background color */
	struct wlr_scene_tree *tree_layer_bg;
	struct wlr_scene_tree *tree_layer_bottom;
	struct wlr_scene_tree *tree_windows;
	struct wlr_scene_tree *tree_layer_top;
	struct wlr_scene_tree *tree_layer_overlay;

	struct wlr_xdg_shell *xdg_shell;
	struct wl_listener new_xdg_surface;
	struct wl_list toplevels; /* mk_toplevel.link, front = most recently focused */

	struct wlr_layer_shell_v1 *layer_shell;
	struct wl_listener new_layer_surface;
	struct wl_list layer_surfaces; /* mk_layer_surface.link */

	struct wlr_foreign_toplevel_manager_v1 *foreign_toplevel_manager;

	struct wlr_cursor *cursor;
	struct wlr_xcursor_manager *cursor_mgr;
	struct wl_listener cursor_motion;
	struct wl_listener cursor_motion_absolute;
	struct wl_listener cursor_button;
	struct wl_listener cursor_axis;
	struct wl_listener cursor_frame;

	struct wlr_seat *seat;
	struct wl_listener new_input;
	struct wl_listener request_cursor;
	struct wl_listener request_set_selection;
	struct wl_list keyboards;
	enum cursor_mode cursor_mode;
	struct mk_toplevel *grabbed_toplevel;
	struct mk_toplevel *focused;
	int ws;                 /* current workspace, 0-based */
	uint32_t next_id;
	int ipc_fd;
	/* alt-tab switcher */
	bool switching;
	int sw_n, sw_sel;
	struct mk_switch_card *sw_cards;
	struct wlr_scene_tree *tree_switcher;
	struct wlr_scene_tree *sw_tree;
	/* screen blanking + idle inhibit */
	bool blanked;
	int blank_ms;
	int inhibitors;
	struct wl_event_source *blank_timer;
	struct wlr_idle_inhibit_manager_v1 *inhibit_mgr;
	struct wl_listener new_inhibitor;
	struct wlr_gamma_control_manager_v1 *gamma_mgr;
	struct wl_listener set_gamma;
	struct wlr_session_lock_manager_v1 *lock_mgr;
	struct wl_listener new_lock;
	struct wlr_session_lock_v1 *lock;
	struct wl_listener lock_new_surface;
	struct wl_listener lock_unlock;
	struct wl_listener lock_destroy;
	struct wlr_surface *lock_focus;
	struct wlr_scene_tree *tree_lock;
	struct wl_event_source *lock_timer;
	struct wl_event_source *idle_timer;
	bool locked;
	bool lock_pending;
	int idle_ms;
	char *kb_layout;
	char *kb_variant;
	double grab_x, grab_y;
	struct wlr_box grab_geobox;
	uint32_t resize_edges;

	struct wlr_output_layout *output_layout;
	struct wl_list outputs;
	struct wl_listener new_output;

	/* Keyboard focus held by an exclusive layer surface (e.g. launcher). */
	struct wlr_layer_surface_v1 *exclusive_focus;
};

struct mk_output {
	struct wl_list link;
	struct mk_server *server;
	struct wlr_output *wlr_output;
	struct wlr_scene_rect *bg;
	struct wlr_scene_rect *lock_rect;
	struct wlr_box usable_area; /* output minus panel exclusive zones, layout coords */
	struct wl_listener frame;
	struct wl_listener request_state;
	struct wl_listener destroy;
};

struct mk_toplevel {
	struct wl_list link;
	struct mk_server *server;
	struct wlr_xdg_toplevel *xdg_toplevel;
	struct wlr_scene_tree *scene_tree; /* container; origin == geometry origin */
	struct wlr_scene_tree *surface_tree;
	struct wlr_scene_rect *border[4]; /* top, bottom, left, right */
	struct wlr_foreign_toplevel_handle_v1 *fth;
	int ws;
	uint32_t id;
	bool mapped;
	bool maximized;
	struct wlr_box saved_box;
	int x, y;

	struct wl_listener map;
	struct wl_listener unmap;
	struct wl_listener commit;
	struct wl_listener destroy;
	struct wl_listener request_move;
	struct wl_listener request_resize;
	struct wl_listener request_maximize;
	struct wl_listener request_fullscreen;
	struct wl_listener set_title;
	struct wl_listener set_app_id;
	struct wl_listener fth_request_activate;
	struct wl_listener fth_request_close;
	struct wl_listener fth_request_maximize;
};

struct mk_popup {
	struct wlr_xdg_popup *xdg_popup;
	struct wl_listener commit;
	struct wl_listener destroy;
	struct wl_listener new_popup;
	struct mk_server *server;
};

struct mk_layer_surface {
	struct wl_list link;
	struct mk_server *server;
	struct wlr_scene_layer_surface_v1 *scene;
	struct wlr_layer_surface_v1 *layer_surface;
	bool mapped;
	struct wl_listener commit;
	struct wl_listener map;
	struct wl_listener unmap;
	struct wl_listener destroy;
	struct wl_listener new_popup;
};

struct mk_keyboard {
	struct wl_list link;
	struct mk_server *server;
	struct wlr_keyboard *wlr_keyboard;
	struct wl_listener modifiers;
	struct wl_listener key;
	struct wl_listener destroy;
};

/* Send a message to the shell over its own unix socket. */
static void shell_send(const char *msg, size_t len) {
	const char *rt = getenv("XDG_RUNTIME_DIR");
	if (!rt) return;
	struct sockaddr_un a = {.sun_family = AF_UNIX};
	snprintf(a.sun_path, sizeof(a.sun_path), "%s/vespara-shell.sock", rt);
	int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
	if (fd < 0) return;
	if (connect(fd, (struct sockaddr *)&a, sizeof(a)) == 0) {
		ssize_t w = write(fd, msg, len);
		(void)w;
	}
	close(fd);
}

static void shell_ping(const char *msg) {
	shell_send(msg, strlen(msg));
}

static void spawn(const char *cmd) {
	if (fork() == 0) {
		setsid();
		execl("/bin/sh", "/bin/sh", "-c", cmd, (void *)NULL);
		_exit(1);
	}
}

/* ------------------------------------------------------------ geometry */

static struct mk_output *output_at_cursor(struct mk_server *server) {
	struct wlr_output *o = wlr_output_layout_output_at(
		server->output_layout, server->cursor->x, server->cursor->y);
	if (o) {
		return o->data;
	}
	struct mk_output *first;
	wl_list_for_each(first, &server->outputs, link) {
		return first;
	}
	return NULL;
}

static void toplevel_geometry(struct mk_toplevel *t, struct wlr_box *box) {
	wlr_xdg_surface_get_geometry(t->xdg_toplevel->base, box);
}

static void update_borders(struct mk_toplevel *t, bool focused) {
	struct wlr_box g;
	toplevel_geometry(t, &g);
	if (getenv("VESPARA_DEBUG")) wlr_log(WLR_INFO, "borders: %s geo=%d,%d %dx%d surf=%dx%d", t->xdg_toplevel->app_id ? t->xdg_toplevel->app_id : "?", g.x, g.y, g.width, g.height, t->xdg_toplevel->base->surface->current.width, t->xdg_toplevel->base->surface->current.height);
	const float *c = focused ? COLOR_FOCUSED : COLOR_UNFOCUSED;
	int w = g.width, h = g.height;
	if (t->maximized) {
		/* no border when maximized: it would stick out of the usable area */
		for (int i = 0; i < 4; i++) {
			wlr_scene_node_set_enabled(&t->border[i]->node, false);
		}
		return;
	}
	for (int i = 0; i < 4; i++) {
		wlr_scene_node_set_enabled(&t->border[i]->node, true);
		wlr_scene_rect_set_color(t->border[i], c);
	}
	wlr_scene_rect_set_size(t->border[0], w + 2 * BORDER, BORDER);
	wlr_scene_node_set_position(&t->border[0]->node, -BORDER, -BORDER);
	wlr_scene_rect_set_size(t->border[1], w + 2 * BORDER, BORDER);
	wlr_scene_node_set_position(&t->border[1]->node, -BORDER, h);
	wlr_scene_rect_set_size(t->border[2], BORDER, h);
	wlr_scene_node_set_position(&t->border[2]->node, -BORDER, 0);
	wlr_scene_rect_set_size(t->border[3], BORDER, h);
	wlr_scene_node_set_position(&t->border[3]->node, w, 0);
}

/* ------------------------------------------------------------ focus */

static struct mk_toplevel *focused_toplevel(struct mk_server *server) {
	return server->focused;
}

static void focus_toplevel(struct mk_toplevel *t) {
	if (t == NULL) {
		return;
	}
	struct mk_server *server = t->server;
	struct wlr_seat *seat = server->seat;
	if (server->focused == t) {
		return;
	}
	struct mk_toplevel *old = server->focused;
	if (old) {
		wlr_xdg_toplevel_set_activated(old->xdg_toplevel, false);
		update_borders(old, false);
		if (old->fth) {
			wlr_foreign_toplevel_handle_v1_set_activated(old->fth, false);
		}
	}
	server->focused = t;
	wlr_scene_node_raise_to_top(&t->scene_tree->node);
	wl_list_remove(&t->link);
	wl_list_insert(&server->toplevels, &t->link);
	wlr_xdg_toplevel_set_activated(t->xdg_toplevel, true);
	update_borders(t, true);
	if (t->fth) {
		wlr_foreign_toplevel_handle_v1_set_activated(t->fth, true);
	}
	struct wlr_keyboard *kb = wlr_seat_get_keyboard(seat);
	if (kb && !server->locked) {
		wlr_seat_keyboard_notify_enter(seat, t->xdg_toplevel->base->surface,
			kb->keycodes, kb->num_keycodes, &kb->modifiers);
	}
}

static void toplevel_set_maximized(struct mk_toplevel *t, bool on) {
	if (!t->mapped || t->maximized == on) {
		return;
	}
	struct mk_output *o = output_at_cursor(t->server);
	if (!o) {
		return;
	}
	if (on) {
		struct wlr_box g;
		toplevel_geometry(t, &g);
		t->saved_box = (struct wlr_box){t->x, t->y, g.width, g.height};
		t->maximized = true;
		t->x = o->usable_area.x;
		t->y = o->usable_area.y;
		wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);
		wlr_xdg_toplevel_set_size(t->xdg_toplevel, o->usable_area.width,
			o->usable_area.height);
		wlr_xdg_toplevel_set_maximized(t->xdg_toplevel, true);
	} else {
		t->maximized = false;
		t->x = t->saved_box.x;
		t->y = t->saved_box.y;
		wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);
		wlr_xdg_toplevel_set_size(t->xdg_toplevel, t->saved_box.width,
			t->saved_box.height);
		wlr_xdg_toplevel_set_maximized(t->xdg_toplevel, false);
	}
	update_borders(t, focused_toplevel(t->server) == t);
}

/* ------------------------------------------------------------ workspaces */

static void focus_best_on_workspace(struct mk_server *server) {
	struct mk_toplevel *t;
	wl_list_for_each(t, &server->toplevels, link) {
		if (t->mapped && t->ws == server->ws) {
			focus_toplevel(t);
			return;
		}
	}
	/* nothing to focus here */
	if (server->focused) {
		wlr_xdg_toplevel_set_activated(server->focused->xdg_toplevel, false);
		update_borders(server->focused, false);
		server->focused = NULL;
	}
	wlr_seat_keyboard_clear_focus(server->seat);
}

static void switch_workspace(struct mk_server *server, int n) {
	if (n < 0 || n >= NUM_WS || n == server->ws) {
		return;
	}
	server->ws = n;
	struct mk_toplevel *t;
	wl_list_for_each(t, &server->toplevels, link) {
		wlr_scene_node_set_enabled(&t->scene_tree->node, t->ws == n);
	}
	if (server->focused && server->focused->ws != n) {
		wlr_xdg_toplevel_set_activated(server->focused->xdg_toplevel, false);
		update_borders(server->focused, false);
		server->focused = NULL;
	}
	focus_best_on_workspace(server);
}

static void move_to_workspace(struct mk_toplevel *t, int n) {
	struct mk_server *server = t->server;
	if (n < 0 || n >= NUM_WS || t->ws == n) {
		return;
	}
	t->ws = n;
	wlr_scene_node_set_enabled(&t->scene_tree->node, n == server->ws);
	if (n != server->ws && server->focused == t) {
		wlr_xdg_toplevel_set_activated(t->xdg_toplevel, false);
		update_borders(t, false);
		server->focused = NULL;
		focus_best_on_workspace(server);
	}
}

/* ------------------------------------------------------------ night light (gamma) + media keys */

static void handle_set_gamma(struct wl_listener *listener, void *data) {
	const struct wlr_gamma_control_manager_v1_set_gamma_event *event = data;
	struct wlr_output_state st;
	wlr_output_state_init(&st);
	if (!wlr_gamma_control_v1_apply(event->control, &st) ||
			!wlr_output_test_state(event->output, &st)) {
		wlr_gamma_control_v1_send_failed_and_destroy(event->control);
		wlr_output_state_finish(&st);
		return;
	}
	wlr_output_commit_state(event->output, &st);
	wlr_output_state_finish(&st);
	wlr_output_schedule_frame(event->output);
}

/* Keys that work without a modifier. Forwarded to the shell, which does the
 * work and shows the on-screen display. Returns true if the key was consumed. */
static bool handle_media_key(xkb_keysym_t sym, uint32_t mods) {
	bool shift = mods & WLR_MODIFIER_SHIFT;
	const char *msg = NULL;
	switch (sym) {
	case XKB_KEY_XF86AudioRaiseVolume:  msg = "vol-up\n"; break;
	case XKB_KEY_XF86AudioLowerVolume:  msg = "vol-down\n"; break;
	case XKB_KEY_XF86AudioMute:         msg = "vol-mute\n"; break;
	case XKB_KEY_XF86AudioMicMute:      msg = "mic-mute\n"; break;
	case XKB_KEY_XF86MonBrightnessUp:   msg = "bright-up\n"; break;
	case XKB_KEY_XF86MonBrightnessDown: msg = "bright-down\n"; break;
	case XKB_KEY_Print:                 msg = shift ? "screenshot-region\n" : "screenshot\n"; break;
	default: return false;
	}
	shell_ping(msg);
	return true;
}

/* ------------------------------------------------------------ alt-tab switcher */

struct mk_switch_card {
	struct mk_toplevel *t;
	struct wlr_scene_rect *hi; /* accent highlight, enabled for the selected card */
	struct wlr_box box;
};

static void json_str(FILE *f, const char *s);

struct thumb_ctx {
	struct wlr_render_pass *pass;
	struct wlr_box g;
	float s;
	int ox, oy;
};

static void thumb_surface(struct wlr_surface *surface, int sx, int sy, void *data) {
	struct thumb_ctx *c = data;
	struct wlr_texture *tex = wlr_surface_get_texture(surface);
	if (!tex) {
		return;
	}
	struct wlr_render_texture_options o = {
		.texture = tex,
		.dst_box = {c->ox + (int)((sx - c->g.x) * c->s), c->oy + (int)((sy - c->g.y) * c->s),
			(int)(surface->current.width * c->s + 0.5f), (int)(surface->current.height * c->s + 0.5f)},
		.filter_mode = WLR_SCALE_FILTER_BILINEAR,
	};
	wlr_render_pass_add_texture(c->pass, &o);
}

/* Snapshot a window into a small buffer. Returns NULL if anything is unsupported
 * (the card then simply has no preview). */
static struct wlr_buffer *render_thumbnail(struct mk_server *server, struct mk_toplevel *t,
		int bufscale, int *out_dw, int *out_dh) {
	struct wlr_box g;
	toplevel_geometry(t, &g);
	if (g.width <= 0 || g.height <= 0) {
		return NULL;
	}
	float s = (float)SW_TW / g.width;
	if ((float)SW_TH / g.height < s) s = (float)SW_TH / g.height;
	if (s > 1.0f) s = 1.0f;
	int dw = (int)(g.width * s + 0.5f), dh = (int)(g.height * s + 0.5f);
	int bw = dw * bufscale, bh = dh * bufscale;

	struct wlr_drm_format fmt = {.format = MK_ARGB8888};
	const struct wlr_drm_format_set *set = wlr_renderer_get_dmabuf_texture_formats(server->renderer);
	const struct wlr_drm_format *from_set = set ? wlr_drm_format_set_get(set, MK_ARGB8888) : NULL;
	struct wlr_buffer *buf = wlr_allocator_create_buffer(server->allocator, bw, bh, from_set ? from_set : &fmt);
	if (!buf) {
		return NULL;
	}
	struct wlr_render_pass *pass = wlr_renderer_begin_buffer_pass(server->renderer, buf, NULL);
	if (!pass) {
		wlr_buffer_drop(buf);
		return NULL;
	}
	wlr_render_pass_add_rect(pass, &(struct wlr_render_rect_options){
		.box = {0, 0, bw, bh}, .color = {0, 0, 0, 0}, .blend_mode = WLR_RENDER_BLEND_MODE_NONE});
	struct thumb_ctx c = {.pass = pass, .g = g, .s = s * bufscale, .ox = 0, .oy = 0};
	wlr_xdg_surface_for_each_surface(t->xdg_toplevel->base, thumb_surface, &c);
	if (!wlr_render_pass_submit(pass)) {
		wlr_buffer_drop(buf);
		return NULL;
	}
	*out_dw = dw;
	*out_dh = dh;
	return buf;
}

static void switcher_send(struct mk_server *server, struct wlr_box *out) {
	char *buf = NULL;
	size_t len = 0;
	FILE *f = open_memstream(&buf, &len);
	fprintf(f, "switcher {\"sel\":%d,\"out\":{\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d},\"cards\":[",
		server->sw_sel, out->x, out->y, out->width, out->height);
	for (int i = 0; i < server->sw_n; i++) {
		struct mk_switch_card *c = &server->sw_cards[i];
		fprintf(f, "%s{\"id\":%u,\"ws\":%d,\"app\":", i ? "," : "", c->t->id, c->t->ws);
		json_str(f, c->t->xdg_toplevel->app_id);
		fputs(",\"title\":", f);
		json_str(f, c->t->xdg_toplevel->title);
		fprintf(f, ",\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d}", c->box.x, c->box.y, c->box.width, c->box.height);
	}
	fputs("]}\n", f);
	fclose(f);
	shell_send(buf, len);
	free(buf);
}

static void switcher_end(struct mk_server *server, bool commit) {
	if (!server->switching) {
		return;
	}
	struct mk_toplevel *target = commit ? server->sw_cards[server->sw_sel].t : NULL;
	server->switching = false;
	if (server->sw_tree) {
		wlr_scene_node_destroy(&server->sw_tree->node);
		server->sw_tree = NULL;
	}
	free(server->sw_cards);
	server->sw_cards = NULL;
	server->sw_n = 0;
	shell_ping("switcher-close\n");
	if (target && target->mapped) {
		switch_workspace(server, target->ws);
		focus_toplevel(target);
	}
}

static void switcher_select(struct mk_server *server, int sel) {
	server->sw_sel = (sel % server->sw_n + server->sw_n) % server->sw_n;
	for (int i = 0; i < server->sw_n; i++) {
		wlr_scene_node_set_enabled(&server->sw_cards[i].hi->node, i == server->sw_sel);
	}
	char msg[48];
	snprintf(msg, sizeof(msg), "switcher-sel %d\n", server->sw_sel);
	shell_ping(msg);
}

static void switcher_start(struct mk_server *server, bool reverse) {
	struct mk_output *o = output_at_cursor(server);
	int n = 0;
	struct mk_toplevel *t;
	wl_list_for_each(t, &server->toplevels, link) {
		if (t->mapped) n++;
	}
	if (!o || n < 2) {
		return;
	}
	server->switching = true;
	server->sw_n = n;
	server->sw_cards = calloc(n, sizeof(*server->sw_cards));
	server->sw_tree = wlr_scene_tree_create(server->tree_switcher);

	struct wlr_box out;
	wlr_output_layout_get_box(server->output_layout, o->wlr_output, &out);
	int per_row = (int)((out.width * 0.9f + SW_GAP) / (SW_CW + SW_GAP));
	if (per_row < 1) per_row = 1;
	int rows = (n + per_row - 1) / per_row;
	int total_h = rows * SW_CH + (rows - 1) * SW_GAP;
	int y0 = out.y + (out.height - total_h) / 2;

	static const float dim[4] = {0.0f, 0.0f, 0.02f, 0.55f};
	static const float card_col[4] = {0.11f, 0.15f, 0.29f, 0.97f};
	struct wlr_scene_rect *dimr = wlr_scene_rect_create(server->sw_tree, out.width, out.height, dim);
	wlr_scene_node_set_position(&dimr->node, out.x, out.y);

	int bufscale = (int)(o->wlr_output->scale + 0.99f);
	if (bufscale < 1) bufscale = 1;
	int i = 0;
	wl_list_for_each(t, &server->toplevels, link) {
		if (!t->mapped) continue;
		int row = i / per_row, col = i % per_row;
		int in_row = (row == rows - 1) ? n - row * per_row : per_row;
		int row_w = in_row * SW_CW + (in_row - 1) * SW_GAP;
		struct mk_switch_card *c = &server->sw_cards[i];
		c->t = t;
		c->box = (struct wlr_box){out.x + (out.width - row_w) / 2 + col * (SW_CW + SW_GAP),
			y0 + row * (SW_CH + SW_GAP), SW_CW, SW_CH};
		c->hi = wlr_scene_rect_create(server->sw_tree, SW_CW + 8, SW_CH + 8, COLOR_FOCUSED);
		wlr_scene_node_set_position(&c->hi->node, c->box.x - 4, c->box.y - 4);
		struct wlr_scene_rect *bg = wlr_scene_rect_create(server->sw_tree, SW_CW, SW_CH, card_col);
		wlr_scene_node_set_position(&bg->node, c->box.x, c->box.y);
		int dw = 0, dh = 0;
		struct wlr_buffer *tb = render_thumbnail(server, t, bufscale, &dw, &dh);
		if (tb) {
			struct wlr_scene_buffer *sb = wlr_scene_buffer_create(server->sw_tree, tb);
			wlr_scene_buffer_set_dest_size(sb, dw, dh);
			wlr_scene_node_set_position(&sb->node, c->box.x + (SW_CW - dw) / 2, c->box.y + 12 + (SW_TH - dh) / 2);
			wlr_buffer_drop(tb);
		}
		i++;
	}
	switcher_select(server, reverse ? n - 1 : 1);
	switcher_send(server, &out);
}

/* ------------------------------------------------------------ screen blanking + idle inhibit */

static void set_outputs_enabled(struct mk_server *server, bool on) {
	struct mk_output *o;
	wl_list_for_each(o, &server->outputs, link) {
		struct wlr_output_state st;
		wlr_output_state_init(&st);
		wlr_output_state_set_enabled(&st, on);
		wlr_output_commit_state(o->wlr_output, &st);
		wlr_output_state_finish(&st);
		if (on) {
			wlr_output_schedule_frame(o->wlr_output);
		}
	}
}

static void blank_screens(struct mk_server *server) {
	if (!server->blanked) {
		server->blanked = true;
		set_outputs_enabled(server, false);
	}
}

static int blank_cb(void *data) {
	struct mk_server *server = data;
	if (server->inhibitors > 0) { /* a video is playing etc.: look again later */
		wl_event_source_timer_update(server->blank_timer, server->blank_ms);
		return 0;
	}
	blank_screens(server);
	return 0;
}

struct mk_inhibitor {
	struct mk_server *server;
	struct wl_listener destroy;
};

static void inhibitor_destroy(struct wl_listener *listener, void *data) {
	struct mk_inhibitor *i = wl_container_of(listener, i, destroy);
	i->server->inhibitors--;
	wl_list_remove(&i->destroy.link);
	free(i);
}

static void server_new_inhibitor(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_inhibitor);
	struct wlr_idle_inhibitor_v1 *inh = data;
	struct mk_inhibitor *i = calloc(1, sizeof(*i));
	i->server = server;
	server->inhibitors++;
	i->destroy.notify = inhibitor_destroy;
	wl_signal_add(&inh->events.destroy, &i->destroy);
}

/* ------------------------------------------------------------ session lock + idle */

struct mk_lock_surface {
	struct mk_server *server;
	struct wlr_session_lock_surface_v1 *ls;
	struct wlr_scene_tree *tree;
	struct wl_listener map;
	struct wl_listener destroy;
};

static void set_locked(struct mk_server *server, bool on) {
	server->locked = on;
	struct mk_output *o;
	wl_list_for_each(o, &server->outputs, link) {
		if (o->lock_rect) {
			wlr_scene_node_set_enabled(&o->lock_rect->node, on);
		}
	}
	if (on) {
		server->cursor_mode = CURSOR_PASSTHROUGH;
		server->grabbed_toplevel = NULL;
		wlr_seat_pointer_clear_focus(server->seat);
	} else {
		server->lock_focus = NULL;
		struct mk_toplevel *f = server->focused;
		server->focused = NULL;
		wlr_seat_keyboard_clear_focus(server->seat);
		if (f && f->mapped && f->ws == server->ws) {
			focus_toplevel(f);
		} else {
			focus_best_on_workspace(server);
		}
	}
}

static int lock_timer_cb(void *data) {
	struct mk_server *server = data;
	if (server->lock && server->lock_pending) {
		server->lock_pending = false;
		wlr_session_lock_v1_send_locked(server->lock);
	}
	return 0;
}

static struct mk_output *output_at_cursor(struct mk_server *server);

static void lock_surface_map(struct wl_listener *listener, void *data) {
	struct mk_lock_surface *m = wl_container_of(listener, m, map);
	struct mk_server *server = m->server;
	struct mk_output *cur = output_at_cursor(server);
	bool prefer = cur && cur->wlr_output == m->ls->output;
	if (!server->lock_focus || prefer) {
		server->lock_focus = m->ls->surface;
		struct wlr_keyboard *kb = wlr_seat_get_keyboard(server->seat);
		if (kb) {
			wlr_seat_keyboard_notify_enter(server->seat, m->ls->surface, kb->keycodes,
				kb->num_keycodes, &kb->modifiers);
		}
	}
}

static void lock_surface_destroy(struct wl_listener *listener, void *data) {
	struct mk_lock_surface *m = wl_container_of(listener, m, destroy);
	if (m->server->lock_focus == m->ls->surface) {
		m->server->lock_focus = NULL;
	}
	wl_list_remove(&m->map.link);
	wl_list_remove(&m->destroy.link);
	free(m);
}

static void lock_new_surface(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, lock_new_surface);
	struct wlr_session_lock_surface_v1 *ls = data;
	struct mk_lock_surface *m = calloc(1, sizeof(*m));
	m->server = server;
	m->ls = ls;
	struct wlr_box box;
	wlr_output_layout_get_box(server->output_layout, ls->output, &box);
	m->tree = wlr_scene_subsurface_tree_create(server->tree_lock, ls->surface);
	wlr_scene_node_set_position(&m->tree->node, box.x, box.y);
	wlr_session_lock_surface_v1_configure(ls, box.width, box.height);
	m->map.notify = lock_surface_map;
	wl_signal_add(&ls->surface->events.map, &m->map);
	m->destroy.notify = lock_surface_destroy;
	wl_signal_add(&ls->events.destroy, &m->destroy);
}

static void lock_unlock(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, lock_unlock);
	set_locked(server, false);
}

static void lock_destroy(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, lock_destroy);
	wl_list_remove(&server->lock_new_surface.link);
	wl_list_remove(&server->lock_unlock.link);
	wl_list_remove(&server->lock_destroy.link);
	server->lock = NULL;
	server->lock_pending = false;
	/* If the locker died without unlocking, the session STAYS locked (black
	 * screen) until a new locker connects. That is the point of this protocol. */
}

static void server_new_lock(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_lock);
	struct wlr_session_lock_v1 *lock = data;
	if (server->lock) {
		wlr_session_lock_v1_destroy(lock);
		return;
	}
	server->lock = lock;
	set_locked(server, true);
	server->lock_new_surface.notify = lock_new_surface;
	wl_signal_add(&lock->events.new_surface, &server->lock_new_surface);
	server->lock_unlock.notify = lock_unlock;
	wl_signal_add(&lock->events.unlock, &server->lock_unlock);
	server->lock_destroy.notify = lock_destroy;
	wl_signal_add(&lock->events.destroy, &server->lock_destroy);
	/* Tell the locker "locked" only after the black fill had time to render. */
	server->lock_pending = true;
	wl_event_source_timer_update(server->lock_timer, 100);
}

static int idle_cb(void *data) {
	struct mk_server *server = data;
	if (server->inhibitors > 0) {
		wl_event_source_timer_update(server->idle_timer, server->idle_ms);
		return 0;
	}
	if (!server->locked) {
		spawn("vespara-lock");
	}
	return 0;
}

static void idle_reset(struct mk_server *server) {
	if (server->blanked) {
		server->blanked = false;
		set_outputs_enabled(server, true);
	}
	if (server->idle_ms > 0 && server->idle_timer) {
		wl_event_source_timer_update(server->idle_timer, server->idle_ms);
	}
	if (server->blank_ms > 0 && server->blank_timer) {
		wl_event_source_timer_update(server->blank_timer, server->blank_ms);
	}
}

/* ------------------------------------------------------------ keybinds */

static int ws_from_sym(xkb_keysym_t sym) {
	switch (sym) {
	case XKB_KEY_1: case XKB_KEY_exclam:     return 0;
	case XKB_KEY_2: case XKB_KEY_at:         return 1;
	case XKB_KEY_3: case XKB_KEY_numbersign: return 2;
	case XKB_KEY_4: case XKB_KEY_dollar:     return 3;
	default: return -1;
	}
}

static bool handle_keybinding(struct mk_server *server, xkb_keysym_t sym,
		uint32_t mods) {
	if (!(mods & WLR_MODIFIER_ALT)) {
		return false;
	}
	bool shift = mods & WLR_MODIFIER_SHIFT;
	int ws = ws_from_sym(sym);
	if (ws >= 0) {
		if (shift) {
			if (server->focused) {
				move_to_workspace(server->focused, ws);
			}
		} else {
			switch_workspace(server, ws);
		}
		return true;
	}
	switch (sym) {
	case XKB_KEY_Return:
		spawn(TERMINAL);
		return true;
	case XKB_KEY_d:
	case XKB_KEY_space:
		shell_ping("toggle-start\n");
		return true;
	case XKB_KEY_l:
		spawn("vespara-lock");
		return true;
	case XKB_KEY_n:
		shell_ping("toggle-center\n");
		return true;
	case XKB_KEY_a:
		shell_ping("toggle-quick\n");
		return true;
	case XKB_KEY_q: {
		struct mk_toplevel *t = focused_toplevel(server);
		if (t) {
			wlr_xdg_toplevel_send_close(t->xdg_toplevel);
		}
		return true;
	}
	case XKB_KEY_f: {
		struct mk_toplevel *t = focused_toplevel(server);
		if (t) {
			toplevel_set_maximized(t, !t->maximized);
		}
		return true;
	}
	case XKB_KEY_Tab:
	case XKB_KEY_ISO_Left_Tab: {
		bool rev = shift || sym == XKB_KEY_ISO_Left_Tab;
		if (!server->switching) {
			switcher_start(server, rev);
		} else {
			switcher_select(server, server->sw_sel + (rev ? -1 : 1));
		}
		return true;
	}
	case XKB_KEY_E:
		if (shift) {
			wl_display_terminate(server->display);
			return true;
		}
		return false;
	default:
		return false;
	}
}

static void keyboard_handle_modifiers(struct wl_listener *listener, void *data) {
	struct mk_keyboard *kb = wl_container_of(listener, kb, modifiers);
	wlr_seat_set_keyboard(kb->server->seat, kb->wlr_keyboard);
	wlr_seat_keyboard_notify_modifiers(kb->server->seat, &kb->wlr_keyboard->modifiers);
	if (kb->server->switching && !(wlr_keyboard_get_modifiers(kb->wlr_keyboard) & WLR_MODIFIER_ALT)) {
		switcher_end(kb->server, true);
	}
}

static void keyboard_handle_key(struct wl_listener *listener, void *data) {
	struct mk_keyboard *kb = wl_container_of(listener, kb, key);
	struct mk_server *server = kb->server;
	struct wlr_keyboard_key_event *event = data;
	struct wlr_seat *seat = server->seat;

	uint32_t keycode = event->keycode + 8;
	const xkb_keysym_t *syms;
	int nsyms = xkb_state_key_get_syms(kb->wlr_keyboard->xkb_state, keycode, &syms);

	bool handled = false;
	uint32_t mods = wlr_keyboard_get_modifiers(kb->wlr_keyboard);
	idle_reset(server);
	if (event->state == WL_KEYBOARD_KEY_STATE_PRESSED && !server->locked && server->switching) {
		for (int i = 0; i < nsyms; i++) {
			if (syms[i] == XKB_KEY_Escape) {
				switcher_end(server, false);
			} else {
				handle_keybinding(server, syms[i], mods); /* Tab / Shift+Tab */
			}
		}
		handled = true;
	} else if (event->state == WL_KEYBOARD_KEY_STATE_PRESSED && !server->locked) {
		for (int i = 0; i < nsyms; i++) {
			handled |= handle_keybinding(server, syms[i], mods) || handle_media_key(syms[i], mods);
		}
	}
	if (!handled) {
		wlr_seat_set_keyboard(seat, kb->wlr_keyboard);
		wlr_seat_keyboard_notify_key(seat, event->time_msec, event->keycode,
			event->state);
	}
}

static void keyboard_handle_destroy(struct wl_listener *listener, void *data) {
	struct mk_keyboard *kb = wl_container_of(listener, kb, destroy);
	wl_list_remove(&kb->modifiers.link);
	wl_list_remove(&kb->key.link);
	wl_list_remove(&kb->destroy.link);
	wl_list_remove(&kb->link);
	free(kb);
}

static void server_new_keyboard(struct mk_server *server, struct wlr_input_device *device) {
	struct wlr_keyboard *wlr_keyboard = wlr_keyboard_from_input_device(device);
	struct mk_keyboard *kb = calloc(1, sizeof(*kb));
	kb->server = server;
	kb->wlr_keyboard = wlr_keyboard;

	struct xkb_context *context = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	struct xkb_rule_names rn = {.layout = server->kb_layout, .variant = server->kb_variant};
	struct xkb_keymap *keymap = xkb_keymap_new_from_names(context, &rn,
		XKB_KEYMAP_COMPILE_NO_FLAGS);
	wlr_keyboard_set_keymap(wlr_keyboard, keymap);
	xkb_keymap_unref(keymap);
	xkb_context_unref(context);
	wlr_keyboard_set_repeat_info(wlr_keyboard, 25, 600);

	kb->modifiers.notify = keyboard_handle_modifiers;
	wl_signal_add(&wlr_keyboard->events.modifiers, &kb->modifiers);
	kb->key.notify = keyboard_handle_key;
	wl_signal_add(&wlr_keyboard->events.key, &kb->key);
	kb->destroy.notify = keyboard_handle_destroy;
	wl_signal_add(&device->events.destroy, &kb->destroy);

	wlr_seat_set_keyboard(server->seat, kb->wlr_keyboard);
	wl_list_insert(&server->keyboards, &kb->link);
}

static void server_new_pointer(struct mk_server *server, struct wlr_input_device *device) {
	wlr_cursor_attach_input_device(server->cursor, device);
}

static void server_new_input(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_input);
	struct wlr_input_device *device = data;
	switch (device->type) {
	case WLR_INPUT_DEVICE_KEYBOARD:
		server_new_keyboard(server, device);
		break;
	case WLR_INPUT_DEVICE_POINTER:
		server_new_pointer(server, device);
		break;
	default:
		break;
	}
	uint32_t caps = WL_SEAT_CAPABILITY_POINTER;
	if (!wl_list_empty(&server->keyboards)) {
		caps |= WL_SEAT_CAPABILITY_KEYBOARD;
	}
	wlr_seat_set_capabilities(server->seat, caps);
}

static void seat_request_cursor(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, request_cursor);
	struct wlr_seat_pointer_request_set_cursor_event *event = data;
	struct wlr_seat_client *focused = server->seat->pointer_state.focused_client;
	if (focused == event->seat_client) {
		wlr_cursor_set_surface(server->cursor, event->surface, event->hotspot_x,
			event->hotspot_y);
	}
}

static void seat_request_set_selection(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, request_set_selection);
	struct wlr_seat_request_set_selection_event *event = data;
	wlr_seat_set_selection(server->seat, event->source, event->serial);
}

/* ------------------------------------------------------------ hit testing */

static struct mk_toplevel *toplevel_at(struct mk_server *server, double lx, double ly,
		struct wlr_surface **surface, double *sx, double *sy) {
	double nx, ny;
	struct wlr_scene_node *root = server->locked ? &server->tree_lock->node : &server->scene->tree.node;
	struct wlr_scene_node *node = wlr_scene_node_at(root, lx, ly, &nx, &ny);
	if (node == NULL || node->type != WLR_SCENE_NODE_BUFFER) {
		return NULL;
	}
	struct wlr_scene_buffer *sb = wlr_scene_buffer_from_node(node);
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(sb);
	if (!ss) {
		return NULL;
	}
	*surface = ss->surface;
	*sx = nx;
	*sy = ny;
	struct wlr_scene_tree *tree = node->parent;
	while (tree != NULL && tree->node.data == NULL) {
		tree = tree->node.parent;
	}
	return tree ? tree->node.data : NULL;
}

static void reset_cursor_mode(struct mk_server *server) {
	server->cursor_mode = CURSOR_PASSTHROUGH;
	server->grabbed_toplevel = NULL;
}

static void process_cursor_move(struct mk_server *server) {
	struct mk_toplevel *t = server->grabbed_toplevel;
	t->x = server->cursor->x - server->grab_x;
	t->y = server->cursor->y - server->grab_y;
	wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);
}

static void process_cursor_resize(struct mk_server *server) {
	struct mk_toplevel *t = server->grabbed_toplevel;
	double bx = server->cursor->x, by = server->cursor->y;
	int left = server->grab_geobox.x;
	int right = server->grab_geobox.x + server->grab_geobox.width;
	int top = server->grab_geobox.y;
	int bottom = server->grab_geobox.y + server->grab_geobox.height;
	double dx = bx - server->grab_x, dy = by - server->grab_y;

	if (server->resize_edges & WLR_EDGE_TOP) {
		top += dy;
		if (top >= bottom - MIN_SIZE) top = bottom - MIN_SIZE;
	} else if (server->resize_edges & WLR_EDGE_BOTTOM) {
		bottom += dy;
		if (bottom <= top + MIN_SIZE) bottom = top + MIN_SIZE;
	}
	if (server->resize_edges & WLR_EDGE_LEFT) {
		left += dx;
		if (left >= right - MIN_SIZE) left = right - MIN_SIZE;
	} else if (server->resize_edges & WLR_EDGE_RIGHT) {
		right += dx;
		if (right <= left + MIN_SIZE) right = left + MIN_SIZE;
	}
	t->x = left;
	t->y = top;
	wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);
	wlr_xdg_toplevel_set_size(t->xdg_toplevel, right - left, bottom - top);
}

static void process_cursor_motion(struct mk_server *server, uint32_t time) {
	if (server->cursor_mode == CURSOR_MOVE) {
		process_cursor_move(server);
		return;
	} else if (server->cursor_mode == CURSOR_RESIZE) {
		process_cursor_resize(server);
		return;
	}
	double sx, sy;
	struct wlr_seat *seat = server->seat;
	struct wlr_surface *surface = NULL;
	struct mk_toplevel *t =
		toplevel_at(server, server->cursor->x, server->cursor->y, &surface, &sx, &sy);
	if (!t) {
		wlr_cursor_set_xcursor(server->cursor, server->cursor_mgr, "default");
	}
	if (surface) {
		wlr_seat_pointer_notify_enter(seat, surface, sx, sy);
		wlr_seat_pointer_notify_motion(seat, time, sx, sy);
	} else {
		wlr_seat_pointer_clear_focus(seat);
	}
}

static void server_cursor_motion(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, cursor_motion);
	struct wlr_pointer_motion_event *event = data;
	idle_reset(server);
	wlr_cursor_move(server->cursor, &event->pointer->base, event->delta_x, event->delta_y);
	process_cursor_motion(server, event->time_msec);
}

static void server_cursor_motion_absolute(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, cursor_motion_absolute);
	struct wlr_pointer_motion_absolute_event *event = data;
	idle_reset(server);
	wlr_cursor_warp_absolute(server->cursor, &event->pointer->base, event->x, event->y);
	process_cursor_motion(server, event->time_msec);
}

static void begin_move(struct mk_toplevel *t) {
	struct mk_server *server = t->server;
	if (t->maximized) {
		return;
	}
	server->grabbed_toplevel = t;
	server->cursor_mode = CURSOR_MOVE;
	server->grab_x = server->cursor->x - t->x;
	server->grab_y = server->cursor->y - t->y;
}

static void begin_resize(struct mk_toplevel *t, uint32_t edges) {
	struct mk_server *server = t->server;
	if (t->maximized) {
		return;
	}
	server->grabbed_toplevel = t;
	server->cursor_mode = CURSOR_RESIZE;
	struct wlr_box g;
	toplevel_geometry(t, &g);
	server->grab_geobox = (struct wlr_box){t->x, t->y, g.width, g.height};
	server->resize_edges = edges;
	server->grab_x = server->cursor->x;
	server->grab_y = server->cursor->y;
}

static void server_cursor_button(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, cursor_button);
	struct wlr_pointer_button_event *event = data;
	idle_reset(server);

	if (event->state == WLR_BUTTON_RELEASED) {
		if (server->cursor_mode != CURSOR_PASSTHROUGH) {
			reset_cursor_mode(server);
			return;
		}
		wlr_seat_pointer_notify_button(server->seat, event->time_msec, event->button,
			event->state);
		return;
	}

	double sx, sy;
	struct wlr_surface *surface = NULL;
	struct mk_toplevel *t =
		toplevel_at(server, server->cursor->x, server->cursor->y, &surface, &sx, &sy);

	struct wlr_keyboard *kb = wlr_seat_get_keyboard(server->seat);
	uint32_t mods = kb ? wlr_keyboard_get_modifiers(kb) : 0;
	if (t && (mods & WLR_MODIFIER_ALT)) {
		focus_toplevel(t);
		if (event->button == 0x110) { /* BTN_LEFT */
			begin_move(t);
			return;
		} else if (event->button == 0x111) { /* BTN_RIGHT */
			struct wlr_box g;
			toplevel_geometry(t, &g);
			uint32_t edges = 0;
			edges |= (server->cursor->x < t->x + g.width / 2) ? WLR_EDGE_LEFT : WLR_EDGE_RIGHT;
			edges |= (server->cursor->y < t->y + g.height / 2) ? WLR_EDGE_TOP : WLR_EDGE_BOTTOM;
			begin_resize(t, edges);
			return;
		}
	}

	wlr_seat_pointer_notify_button(server->seat, event->time_msec, event->button,
		event->state);
	if (t) {
		focus_toplevel(t);
	}
}

static void server_cursor_axis(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, cursor_axis);
	struct wlr_pointer_axis_event *event = data;
	idle_reset(server);
	wlr_seat_pointer_notify_axis(server->seat, event->time_msec, event->orientation,
		event->delta, event->delta_discrete, event->source);
}

static void server_cursor_frame(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, cursor_frame);
	wlr_seat_pointer_notify_frame(server->seat);
}

/* ------------------------------------------------------------ layer shell */

static void arrange_layers(struct mk_output *output) {
	struct mk_server *server = output->server;
	struct wlr_box full = {0};
	wlr_output_layout_get_box(server->output_layout, output->wlr_output, &full);
	struct wlr_box usable = full;

	/* Exclusive-zone surfaces (panels) shrink the usable area. Process from
	 * the top layer down, as the protocol requires. */
	for (int layer = ZWLR_LAYER_SHELL_V1_LAYER_OVERLAY;
			layer >= ZWLR_LAYER_SHELL_V1_LAYER_BACKGROUND; layer--) {
		struct mk_layer_surface *ls;
		wl_list_for_each(ls, &server->layer_surfaces, link) {
			if (ls->layer_surface->output != output->wlr_output ||
					(int)ls->layer_surface->current.layer != layer) {
				continue;
			}
			wlr_scene_layer_surface_v1_configure(ls->scene, &full, &usable);
		}
	}
	output->usable_area = usable;

	/* Re-fit maximized windows on this output. */
	struct mk_toplevel *t;
	wl_list_for_each(t, &server->toplevels, link) {
		if (t->maximized) {
			t->x = usable.x;
			t->y = usable.y;
			wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);
			wlr_xdg_toplevel_set_size(t->xdg_toplevel, usable.width, usable.height);
		}
	}

	/* Keyboard focus for exclusive layer surfaces (launcher etc.). */
	struct mk_layer_surface *ls;
	server->exclusive_focus = NULL;
	for (int layer = ZWLR_LAYER_SHELL_V1_LAYER_OVERLAY;
			layer >= ZWLR_LAYER_SHELL_V1_LAYER_TOP; layer--) {
		wl_list_for_each(ls, &server->layer_surfaces, link) {
			if (ls->mapped && (int)ls->layer_surface->current.layer == layer &&
					ls->layer_surface->current.keyboard_interactive ==
						ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_EXCLUSIVE) {
				server->exclusive_focus = ls->layer_surface;
			}
		}
		if (server->exclusive_focus) {
			break;
		}
	}
	if (server->exclusive_focus && !server->locked) {
		struct wlr_keyboard *kb = wlr_seat_get_keyboard(server->seat);
		if (kb) {
			wlr_seat_keyboard_notify_enter(server->seat,
				server->exclusive_focus->surface, kb->keycodes, kb->num_keycodes,
				&kb->modifiers);
		}
	}
}

static void layer_surface_commit(struct wl_listener *listener, void *data) {
	struct mk_layer_surface *ls = wl_container_of(listener, ls, commit);
	if (!ls->layer_surface->initialized || !ls->layer_surface->output) {
		return;
	}
	struct mk_output *o = ls->layer_surface->output->data;
	arrange_layers(o);
}

static void layer_surface_map(struct wl_listener *listener, void *data) {
	struct mk_layer_surface *ls = wl_container_of(listener, ls, map);
	ls->mapped = true;
	if (ls->layer_surface->output) {
		arrange_layers(ls->layer_surface->output->data);
	}
}

static void layer_surface_unmap(struct wl_listener *listener, void *data) {
	struct mk_layer_surface *ls = wl_container_of(listener, ls, unmap);
	ls->mapped = false;
	struct mk_server *server = ls->server;
	if (server->exclusive_focus == ls->layer_surface) {
		server->exclusive_focus = NULL;
		struct mk_toplevel *t;
		wl_list_for_each(t, &server->toplevels, link) {
			if (t->mapped && t->ws == server->ws) {
				/* force a re-enter: clear then focus */
				wlr_seat_keyboard_clear_focus(server->seat);
				server->focused = NULL;
				focus_toplevel(t);
				break;
			}
		}
	}
	if (ls->layer_surface->output) {
		arrange_layers(ls->layer_surface->output->data);
	}
}

static void layer_surface_destroy(struct wl_listener *listener, void *data) {
	struct mk_layer_surface *ls = wl_container_of(listener, ls, destroy);
	struct wlr_output *out = ls->layer_surface->output;
	wl_list_remove(&ls->commit.link);
	wl_list_remove(&ls->map.link);
	wl_list_remove(&ls->unmap.link);
	wl_list_remove(&ls->destroy.link);
	wl_list_remove(&ls->new_popup.link);
	wl_list_remove(&ls->link);
	if (ls->server->exclusive_focus == ls->layer_surface) {
		ls->server->exclusive_focus = NULL;
	}
	free(ls);
	if (out && out->data) {
		arrange_layers(out->data);
	}
}

static void popup_commit(struct wl_listener *listener, void *data);
static void popup_destroy(struct wl_listener *listener, void *data);
static void popup_new_popup(struct wl_listener *listener, void *data);

static void create_popup(struct mk_server *server, struct wlr_xdg_popup *xdg_popup,
		struct wlr_scene_tree *parent_tree) {
	struct mk_popup *popup = calloc(1, sizeof(*popup));
	popup->server = server;
	popup->xdg_popup = xdg_popup;
	xdg_popup->base->data = wlr_scene_xdg_surface_create(parent_tree, xdg_popup->base);
	popup->commit.notify = popup_commit;
	wl_signal_add(&xdg_popup->base->surface->events.commit, &popup->commit);
	popup->destroy.notify = popup_destroy;
	wl_signal_add(&xdg_popup->base->events.destroy, &popup->destroy);
	popup->new_popup.notify = popup_new_popup;
	wl_signal_add(&xdg_popup->base->events.new_popup, &popup->new_popup);
}

static void popup_commit(struct wl_listener *listener, void *data) {
	struct mk_popup *popup = wl_container_of(listener, popup, commit);
	if (popup->xdg_popup->base->initial_commit) {
		/* Keep popups on screen. */
		struct mk_output *o = output_at_cursor(popup->server);
		if (o) {
			struct wlr_box box;
			wlr_output_layout_get_box(popup->server->output_layout, o->wlr_output, &box);
			struct wlr_scene_tree *tree = popup->xdg_popup->base->data;
			/* Target box is relative to the popup's parent. Approximate with
			 * the output box shifted by the popup tree's parent position. */
			int lx, ly;
			wlr_scene_node_coords(&tree->node.parent->node, &lx, &ly);
			box.x -= lx;
			box.y -= ly;
			wlr_xdg_popup_unconstrain_from_box(popup->xdg_popup, &box);
		} else {
			wlr_xdg_surface_schedule_configure(popup->xdg_popup->base);
		}
	}
}

static void popup_destroy(struct wl_listener *listener, void *data) {
	struct mk_popup *popup = wl_container_of(listener, popup, destroy);
	wl_list_remove(&popup->commit.link);
	wl_list_remove(&popup->destroy.link);
	wl_list_remove(&popup->new_popup.link);
	free(popup);
}

static void popup_new_popup(struct wl_listener *listener, void *data) {
	struct mk_popup *popup = wl_container_of(listener, popup, new_popup);
	struct wlr_xdg_popup *child = data;
	create_popup(popup->server, child, popup->xdg_popup->base->data);
}

static void layer_surface_new_popup(struct wl_listener *listener, void *data) {
	struct mk_layer_surface *ls = wl_container_of(listener, ls, new_popup);
	struct wlr_xdg_popup *popup = data;
	create_popup(ls->server, popup, ls->scene->tree);
}

static void server_new_layer_surface(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_layer_surface);
	struct wlr_layer_surface_v1 *layer_surface = data;

	if (!layer_surface->output) {
		struct mk_output *o = output_at_cursor(server);
		if (!o) {
			wlr_layer_surface_v1_destroy(layer_surface);
			return;
		}
		layer_surface->output = o->wlr_output;
	}

	struct wlr_scene_tree *parent;
	switch (layer_surface->pending.layer) {
	case ZWLR_LAYER_SHELL_V1_LAYER_BACKGROUND: parent = server->tree_layer_bg; break;
	case ZWLR_LAYER_SHELL_V1_LAYER_BOTTOM:     parent = server->tree_layer_bottom; break;
	case ZWLR_LAYER_SHELL_V1_LAYER_TOP:        parent = server->tree_layer_top; break;
	default:                                   parent = server->tree_layer_overlay; break;
	}

	struct mk_layer_surface *ls = calloc(1, sizeof(*ls));
	ls->server = server;
	ls->layer_surface = layer_surface;
	ls->scene = wlr_scene_layer_surface_v1_create(parent, layer_surface);
	ls->scene->tree->node.data = NULL;

	ls->commit.notify = layer_surface_commit;
	wl_signal_add(&layer_surface->surface->events.commit, &ls->commit);
	ls->map.notify = layer_surface_map;
	wl_signal_add(&layer_surface->surface->events.map, &ls->map);
	ls->unmap.notify = layer_surface_unmap;
	wl_signal_add(&layer_surface->surface->events.unmap, &ls->unmap);
	ls->destroy.notify = layer_surface_destroy;
	wl_signal_add(&layer_surface->events.destroy, &ls->destroy);
	ls->new_popup.notify = layer_surface_new_popup;
	wl_signal_add(&layer_surface->events.new_popup, &ls->new_popup);

	wl_list_insert(&server->layer_surfaces, &ls->link);
}

/* ------------------------------------------------------------ xdg toplevels */

static void toplevel_update_fth_title(struct mk_toplevel *t) {
	if (t->fth) {
		wlr_foreign_toplevel_handle_v1_set_title(t->fth,
			t->xdg_toplevel->title ? t->xdg_toplevel->title : "");
	}
}

static void toplevel_update_fth_app_id(struct mk_toplevel *t) {
	if (t->fth) {
		wlr_foreign_toplevel_handle_v1_set_app_id(t->fth,
			t->xdg_toplevel->app_id ? t->xdg_toplevel->app_id : "");
	}
}

static void toplevel_set_title(struct wl_listener *l, void *d) {
	struct mk_toplevel *t = wl_container_of(l, t, set_title);
	toplevel_update_fth_title(t);
}

static void toplevel_set_app_id(struct wl_listener *l, void *d) {
	struct mk_toplevel *t = wl_container_of(l, t, set_app_id);
	toplevel_update_fth_app_id(t);
}

static void fth_activate(struct wl_listener *l, void *d) {
	struct mk_toplevel *t = wl_container_of(l, t, fth_request_activate);
	focus_toplevel(t);
}

static void fth_close(struct wl_listener *l, void *d) {
	struct mk_toplevel *t = wl_container_of(l, t, fth_request_close);
	wlr_xdg_toplevel_send_close(t->xdg_toplevel);
}

static void fth_maximize(struct wl_listener *l, void *d) {
	struct mk_toplevel *t = wl_container_of(l, t, fth_request_maximize);
	struct wlr_foreign_toplevel_handle_v1_maximized_event *ev = d;
	toplevel_set_maximized(t, ev->maximized);
}

static void toplevel_map(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, map);
	struct mk_server *server = t->server;
	t->mapped = true;
	wlr_scene_node_set_enabled(&t->scene_tree->node, true);
	t->ws = server->ws;
	t->id = ++server->next_id;
	wl_list_insert(&server->toplevels, &t->link);

	/* Cascade new windows a bit so they don't stack exactly. */
	struct mk_output *o = output_at_cursor(server);
	int n = wl_list_length(&server->toplevels);
	if (o) {
		t->x = o->usable_area.x + 60 + (n % 8) * 32;
		t->y = o->usable_area.y + 50 + (n % 8) * 32;
	} else {
		t->x = 60;
		t->y = 50;
	}
	if (o && t->xdg_toplevel->app_id && strcmp(t->xdg_toplevel->app_id, "org.vespara.Welcome") == 0) {
		struct wlr_box g;
		toplevel_geometry(t, &g);
		t->x = o->usable_area.x + (o->usable_area.width - g.width) / 2;
		t->y = o->usable_area.y + (o->usable_area.height - g.height) / 2;
	}
	if (o) {
		struct wlr_box g;
		toplevel_geometry(t, &g);
		int r = o->usable_area.x + o->usable_area.width, b = o->usable_area.y + o->usable_area.height;
		if (g.width > 0 && t->x + g.width > r) t->x = r - g.width;
		if (g.height > 0 && t->y + g.height > b) t->y = b - g.height;
		if (t->x < o->usable_area.x) t->x = o->usable_area.x;
		if (t->y < o->usable_area.y) t->y = o->usable_area.y;
	}
	wlr_scene_node_set_position(&t->scene_tree->node, t->x, t->y);

	t->fth = wlr_foreign_toplevel_handle_v1_create(server->foreign_toplevel_manager);
	t->fth_request_activate.notify = fth_activate;
	wl_signal_add(&t->fth->events.request_activate, &t->fth_request_activate);
	t->fth_request_close.notify = fth_close;
	wl_signal_add(&t->fth->events.request_close, &t->fth_request_close);
	t->fth_request_maximize.notify = fth_maximize;
	wl_signal_add(&t->fth->events.request_maximize, &t->fth_request_maximize);
	toplevel_update_fth_title(t);
	toplevel_update_fth_app_id(t);
	if (o) {
		wlr_foreign_toplevel_handle_v1_output_enter(t->fth, o->wlr_output);
	}

	/* wl_list_insert above put it at the front; focus_toplevel expects to
	 * reinsert, and bails early if the surface is already focused. */
	focus_toplevel(t);
}

static void toplevel_unmap(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, unmap);
	struct mk_server *server = t->server;
	if (server->switching) {
		switcher_end(server, false);
	}
	t->mapped = false;
	wlr_scene_node_set_enabled(&t->scene_tree->node, false);
	if (t == server->grabbed_toplevel) {
		reset_cursor_mode(server);
	}
	if (t->fth) {
		wl_list_remove(&t->fth_request_activate.link);
		wl_list_remove(&t->fth_request_close.link);
		wl_list_remove(&t->fth_request_maximize.link);
		wlr_foreign_toplevel_handle_v1_destroy(t->fth);
		t->fth = NULL;
	}
	bool had_focus = server->focused == t;
	wl_list_remove(&t->link);
	if (had_focus) {
		server->focused = NULL;
		wlr_seat_keyboard_clear_focus(server->seat);
		focus_best_on_workspace(server);
	}
}

static void toplevel_commit(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, commit);
	if (t->xdg_toplevel->base->initial_commit) {
		wlr_xdg_toplevel_set_size(t->xdg_toplevel, 0, 0);
		return;
	}
	/* wlr_scene_xdg_surface already aligns the geometry origin with the
	 * tree origin, so we only refresh borders here. */
	update_borders(t, focused_toplevel(t->server) == t);
}

static void toplevel_destroy(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, destroy);
	wl_list_remove(&t->map.link);
	wl_list_remove(&t->unmap.link);
	wl_list_remove(&t->commit.link);
	wl_list_remove(&t->destroy.link);
	wl_list_remove(&t->request_move.link);
	wl_list_remove(&t->request_resize.link);
	wl_list_remove(&t->request_maximize.link);
	wl_list_remove(&t->request_fullscreen.link);
	wl_list_remove(&t->set_title.link);
	wl_list_remove(&t->set_app_id.link);
	free(t);
}

static void toplevel_request_move(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, request_move);
	focus_toplevel(t);
	begin_move(t);
}

static void toplevel_request_resize(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, request_resize);
	struct wlr_xdg_toplevel_resize_event *event = data;
	focus_toplevel(t);
	begin_resize(t, event->edges);
}

static void toplevel_request_maximize(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, request_maximize);
	if (!t->xdg_toplevel->base->initialized) {
		return;
	}
	if (t->mapped) {
		toplevel_set_maximized(t, t->xdg_toplevel->requested.maximized);
	}
	wlr_xdg_surface_schedule_configure(t->xdg_toplevel->base);
}

static void toplevel_request_fullscreen(struct wl_listener *listener, void *data) {
	struct mk_toplevel *t = wl_container_of(listener, t, request_fullscreen);
	if (t->xdg_toplevel->base->initialized) {
		wlr_xdg_surface_schedule_configure(t->xdg_toplevel->base);
	}
}

static void server_new_xdg_surface(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_xdg_surface);
	struct wlr_xdg_surface *xdg_surface = data;

	/* Popups are delivered through their parent's events.new_popup. */
	if (xdg_surface->role == WLR_XDG_SURFACE_ROLE_POPUP) {
		struct wlr_xdg_surface *parent =
			wlr_xdg_surface_try_from_wlr_surface(xdg_surface->popup->parent);
		if (parent) {
			struct wlr_scene_tree *parent_tree = parent->data;
			if (parent_tree) {
				create_popup(server, xdg_surface->popup, parent_tree);
			}
		}
		/* layer-shell parents are handled by layer_surface_new_popup */
		return;
	}
	if (xdg_surface->role != WLR_XDG_SURFACE_ROLE_TOPLEVEL) {
		return;
	}

	struct mk_toplevel *t = calloc(1, sizeof(*t));
	t->server = server;
	t->xdg_toplevel = xdg_surface->toplevel;
	t->scene_tree = wlr_scene_tree_create(server->tree_windows);
	t->scene_tree->node.data = t;
	wlr_scene_node_set_enabled(&t->scene_tree->node, false); /* shown on map */
	for (int i = 0; i < 4; i++) {
		t->border[i] = wlr_scene_rect_create(t->scene_tree, 0, 0, COLOR_UNFOCUSED);
	}
	t->surface_tree = wlr_scene_xdg_surface_create(t->scene_tree, xdg_surface);
	xdg_surface->data = t->surface_tree;

	t->map.notify = toplevel_map;
	wl_signal_add(&xdg_surface->surface->events.map, &t->map);
	t->unmap.notify = toplevel_unmap;
	wl_signal_add(&xdg_surface->surface->events.unmap, &t->unmap);
	t->commit.notify = toplevel_commit;
	wl_signal_add(&xdg_surface->surface->events.commit, &t->commit);
	t->destroy.notify = toplevel_destroy;
	wl_signal_add(&xdg_surface->events.destroy, &t->destroy);

	struct wlr_xdg_toplevel *tl = xdg_surface->toplevel;
	t->request_move.notify = toplevel_request_move;
	wl_signal_add(&tl->events.request_move, &t->request_move);
	t->request_resize.notify = toplevel_request_resize;
	wl_signal_add(&tl->events.request_resize, &t->request_resize);
	t->request_maximize.notify = toplevel_request_maximize;
	wl_signal_add(&tl->events.request_maximize, &t->request_maximize);
	t->request_fullscreen.notify = toplevel_request_fullscreen;
	wl_signal_add(&tl->events.request_fullscreen, &t->request_fullscreen);
	t->set_title.notify = toplevel_set_title;
	wl_signal_add(&tl->events.set_title, &t->set_title);
	t->set_app_id.notify = toplevel_set_app_id;
	wl_signal_add(&tl->events.set_app_id, &t->set_app_id);
}

/* ------------------------------------------------------------ settings helpers */

static void apply_keymap(struct mk_server *server, const char *layout, const char *variant) {
	free(server->kb_layout);
	free(server->kb_variant);
	server->kb_layout = (layout && *layout) ? strdup(layout) : NULL;
	server->kb_variant = (variant && *variant) ? strdup(variant) : NULL;
	struct xkb_rule_names rn = {.layout = server->kb_layout, .variant = server->kb_variant};
	struct xkb_context *ctx = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	struct xkb_keymap *km = xkb_keymap_new_from_names(ctx, &rn, XKB_KEYMAP_COMPILE_NO_FLAGS);
	if (km) {
		struct mk_keyboard *kb;
		wl_list_for_each(kb, &server->keyboards, link) {
			wlr_keyboard_set_keymap(kb->wlr_keyboard, km);
		}
		xkb_keymap_unref(km);
	}
	xkb_context_unref(ctx);
}

static void refresh_output(struct mk_output *o) {
	struct wlr_box box;
	wlr_output_layout_get_box(o->server->output_layout, o->wlr_output, &box);
	wlr_scene_rect_set_size(o->bg, box.width, box.height);
	wlr_scene_node_set_position(&o->bg->node, box.x, box.y);
	wlr_scene_rect_set_size(o->lock_rect, box.width, box.height);
	wlr_scene_node_set_position(&o->lock_rect->node, box.x, box.y);
	arrange_layers(o);
}

static bool output_apply(struct mk_output *o, int w, int h, int refresh, float scale) {
	struct wlr_output *out = o->wlr_output;
	struct wlr_output_state st;
	wlr_output_state_init(&st);
	if (w > 0 && h > 0) {
		struct wlr_output_mode *m, *found = NULL;
		wl_list_for_each(m, &out->modes, link) {
			if (m->width == w && m->height == h &&
					(refresh <= 0 || abs(m->refresh - refresh) < 600)) {
				found = m;
				break;
			}
		}
		if (found) {
			wlr_output_state_set_mode(&st, found);
		} else if (wl_list_empty(&out->modes)) {
			wlr_output_state_set_custom_mode(&st, w, h, refresh > 0 ? refresh : 60000);
		} else {
			wlr_output_state_finish(&st);
			return false;
		}
	}
	if (scale > 0.5f && scale <= 4.0f) {
		wlr_output_state_set_scale(&st, scale);
	}
	bool ok = wlr_output_commit_state(out, &st);
	wlr_output_state_finish(&st);
	if (ok) {
		refresh_output(o);
	}
	return ok;
}

static struct mk_output *output_by_name(struct mk_server *server, const char *name) {
	struct mk_output *o;
	wl_list_for_each(o, &server->outputs, link) {
		if (strcmp(o->wlr_output->name, name) == 0) {
			return o;
		}
	}
	return NULL;
}

/* ------------------------------------------------------------ IPC */
/* Tiny line protocol on $XDG_RUNTIME_DIR/vespara.sock used by the shell:
 *   state            -> JSON {workspace, workspaces, windows:[...]}
 *   workspace N      -> switch (1-based)
 *   focus ID / close ID / move N / quit
 */
static void json_str(FILE *f, const char *s) {
	fputc('"', f);
	for (; s && *s; s++) {
		unsigned char c = *s;
		if (c == '"' || c == '\\') { fputc('\\', f); fputc(c, f); }
		else if (c < 0x20) { fprintf(f, "\\u%04x", c); }
		else { fputc(c, f); }
	}
	fputc('"', f);
}

static struct mk_toplevel *toplevel_by_id(struct mk_server *server, uint32_t id) {
	struct mk_toplevel *t;
	wl_list_for_each(t, &server->toplevels, link) {
		if (t->id == id && t->mapped) {
			return t;
		}
	}
	return NULL;
}

static int ipc_accept(int fd, uint32_t mask, void *data) {
	struct mk_server *server = data;
	int c = accept4(fd, NULL, NULL, SOCK_CLOEXEC);
	if (c < 0) {
		return 0;
	}
	struct timeval tv = {0, 100000};
	setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
	char buf[128] = {0};
	ssize_t n = read(c, buf, sizeof(buf) - 1);
	if (n <= 0) {
		close(c);
		return 0;
	}
	char *nl = strchr(buf, '\n');
	if (nl) *nl = 0;

	char *out = NULL;
	size_t outlen = 0;
	FILE *f = open_memstream(&out, &outlen);
	unsigned arg = 0;
	if (server->locked && strcmp(buf, "state") != 0 && strncmp(buf, "idle ", 5) != 0 &&
			strncmp(buf, "blank ", 6) != 0 && strncmp(buf, "dpms ", 5) != 0 && strcmp(buf, "outputs") != 0) {
		fputs("error\n", f);
	} else if (strncmp(buf, "switch ", 7) == 0) {
		if (strcmp(buf, "switch start") == 0) switcher_start(server, false);
		else if (strcmp(buf, "switch next") == 0 && server->switching) switcher_select(server, server->sw_sel + 1);
		else if (strcmp(buf, "switch commit") == 0) switcher_end(server, true);
		else if (strcmp(buf, "switch cancel") == 0) switcher_end(server, false);
		fputs("ok\n", f);
	} else if (strncmp(buf, "blank ", 6) == 0) {
		int secs = 0;
		sscanf(buf, "blank %d", &secs);
		server->blank_ms = secs > 0 ? secs * 1000 : 0;
		if (server->blank_ms > 0) idle_reset(server);
		else wl_event_source_timer_update(server->blank_timer, 0);
		fputs("ok\n", f);
	} else if (strcmp(buf, "dpms off") == 0) {
		blank_screens(server);
		fputs("ok\n", f);
	} else if (strcmp(buf, "dpms on") == 0) {
		idle_reset(server);
		fputs("ok\n", f);
	} else if (strncmp(buf, "idle ", 5) == 0) {
		int secs = 0;
		sscanf(buf, "idle %d", &secs);
		server->idle_ms = secs > 0 ? secs * 1000 : 0;
		if (server->idle_ms > 0) idle_reset(server);
		else wl_event_source_timer_update(server->idle_timer, 0);
		fputs("ok\n", f);
	} else if (strcmp(buf, "state") == 0) {
		fprintf(f, "{\"workspace\":%d,\"workspaces\":%d,\"locked\":%s,\"windows\":[", server->ws, NUM_WS, server->locked ? "true" : "false");
		bool first = true;
		struct mk_toplevel *t;
		wl_list_for_each(t, &server->toplevels, link) {
			if (!t->mapped) continue;
			fprintf(f, "%s{\"id\":%u,\"ws\":%d,\"focused\":%s,\"app_id\":", first ? "" : ",",
				t->id, t->ws, server->focused == t ? "true" : "false");
			json_str(f, t->xdg_toplevel->app_id);
			fputs(",\"title\":", f);
			json_str(f, t->xdg_toplevel->title);
			fputc('}', f);
			first = false;
		}
		fputs("]}\n", f);
	} else if (sscanf(buf, "workspace %u", &arg) == 1 && arg >= 1) {
		switch_workspace(server, (int)arg - 1);
		fputs("ok\n", f);
	} else if (sscanf(buf, "focus %u", &arg) == 1) {
		struct mk_toplevel *t = toplevel_by_id(server, arg);
		if (t) {
			switch_workspace(server, t->ws);
			focus_toplevel(t);
		}
		fputs("ok\n", f);
	} else if (sscanf(buf, "close %u", &arg) == 1) {
		struct mk_toplevel *t = toplevel_by_id(server, arg);
		if (t) wlr_xdg_toplevel_send_close(t->xdg_toplevel);
		fputs("ok\n", f);
	} else if (sscanf(buf, "move %u", &arg) == 1 && arg >= 1) {
		if (server->focused) move_to_workspace(server->focused, (int)arg - 1);
		fputs("ok\n", f);
	} else if (strcmp(buf, "outputs") == 0) {
		fputc('[', f);
		bool first = true;
		struct mk_output *o;
		wl_list_for_each(o, &server->outputs, link) {
			struct wlr_output *w = o->wlr_output;
			fprintf(f, "%s{\"name\":", first ? "" : ",");
			json_str(f, w->name);
			fputs(",\"model\":", f);
			json_str(f, w->model ? w->model : "");
			fprintf(f, ",\"enabled\":%s,\"width\":%d,\"height\":%d,\"refresh\":%d,\"scale\":%.2f,\"modes\":[",
				w->enabled ? "true" : "false", w->width, w->height, w->refresh, w->scale);
			struct wlr_output_mode *m;
			bool mf = true;
			wl_list_for_each(m, &w->modes, link) {
				fprintf(f, "%s{\"w\":%d,\"h\":%d,\"r\":%d,\"preferred\":%s}", mf ? "" : ",",
					m->width, m->height, m->refresh, m->preferred ? "true" : "false");
				mf = false;
			}
			fputs("]}", f);
			first = false;
		}
		fputs("]\n", f);
	} else if (strncmp(buf, "mode ", 5) == 0) {
		char name[32];
		int w, h, r = 0;
		struct mk_output *o;
		if (sscanf(buf, "mode %31s %d %d %d", name, &w, &h, &r) >= 3 &&
				(o = output_by_name(server, name)) && output_apply(o, w, h, r, 0)) {
			fputs("ok\n", f);
		} else {
			fputs("error\n", f);
		}
	} else if (strncmp(buf, "scale ", 6) == 0) {
		char name[32];
		float sc;
		struct mk_output *o;
		if (sscanf(buf, "scale %31s %f", name, &sc) == 2 &&
				(o = output_by_name(server, name)) && output_apply(o, 0, 0, 0, sc)) {
			fputs("ok\n", f);
		} else {
			fputs("error\n", f);
		}
	} else if (strncmp(buf, "accent ", 7) == 0) {
		unsigned rgb;
		if (sscanf(buf, "accent %6x", &rgb) == 1) {
			COLOR_FOCUSED[0] = ((rgb >> 16) & 0xff) / 255.0f;
			COLOR_FOCUSED[1] = ((rgb >> 8) & 0xff) / 255.0f;
			COLOR_FOCUSED[2] = (rgb & 0xff) / 255.0f;
			if (server->focused) update_borders(server->focused, true);
			fputs("ok\n", f);
		} else {
			fputs("error\n", f);
		}
	} else if (strncmp(buf, "layout", 6) == 0) {
		char layout[32] = "", variant[32] = "";
		sscanf(buf, "layout %31[a-zA-Z0-9,_-] %31[a-zA-Z0-9,_-]", layout, variant);
		apply_keymap(server, layout, variant);
		fputs("ok\n", f);
	} else if (strcmp(buf, "quit") == 0) {
		fputs("ok\n", f);
		wl_display_terminate(server->display);
	} else {
		fputs("error\n", f);
	}
	fclose(f);
	if (out) {
		ssize_t w = write(c, out, outlen);
		(void)w;
		free(out);
	}
	close(c);
	return 0;
}

static void ipc_start(struct mk_server *server) {
	const char *rt = getenv("XDG_RUNTIME_DIR");
	if (!rt) return;
	struct sockaddr_un addr = {.sun_family = AF_UNIX};
	snprintf(addr.sun_path, sizeof(addr.sun_path), "%s/vespara.sock", rt);
	unlink(addr.sun_path);
	int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
	if (fd < 0 || bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0 || listen(fd, 8) < 0) {
		wlr_log(WLR_ERROR, "IPC socket setup failed");
		return;
	}
	server->ipc_fd = fd;
	wl_event_loop_add_fd(wl_display_get_event_loop(server->display), fd,
		WL_EVENT_READABLE, ipc_accept, server);
	setenv("VESPARA_SOCK", addr.sun_path, true);
}

/* ------------------------------------------------------------ outputs */

static void output_frame(struct wl_listener *listener, void *data) {
	struct mk_output *output = wl_container_of(listener, output, frame);
	struct wlr_scene_output *scene_output =
		wlr_scene_get_scene_output(output->server->scene, output->wlr_output);
	wlr_scene_output_commit(scene_output, NULL);
	struct timespec now;
	clock_gettime(CLOCK_MONOTONIC, &now);
	wlr_scene_output_send_frame_done(scene_output, &now);
}

static void output_request_state(struct wl_listener *listener, void *data) {
	struct mk_output *output = wl_container_of(listener, output, request_state);
	const struct wlr_output_event_request_state *event = data;
	wlr_output_commit_state(output->wlr_output, event->state);
}

static void output_destroy(struct wl_listener *listener, void *data) {
	struct mk_output *output = wl_container_of(listener, output, destroy);
	wl_list_remove(&output->frame.link);
	wl_list_remove(&output->request_state.link);
	wl_list_remove(&output->destroy.link);
	wl_list_remove(&output->link);
	wlr_scene_node_destroy(&output->lock_rect->node);
	wlr_scene_node_destroy(&output->bg->node);
	free(output);
}

static void server_new_output(struct wl_listener *listener, void *data) {
	struct mk_server *server = wl_container_of(listener, server, new_output);
	struct wlr_output *wlr_output = data;

	wlr_output_init_render(wlr_output, server->allocator, server->renderer);

	struct wlr_output_state state;
	wlr_output_state_init(&state);
	wlr_output_state_set_enabled(&state, true);
	struct wlr_output_mode *mode = wlr_output_preferred_mode(wlr_output);
	if (mode != NULL) {
		wlr_output_state_set_mode(&state, mode);
	}
	wlr_output_commit_state(wlr_output, &state);
	wlr_output_state_finish(&state);

	struct mk_output *output = calloc(1, sizeof(*output));
	output->wlr_output = wlr_output;
	output->server = server;
	wlr_output->data = output;
	output->frame.notify = output_frame;
	wl_signal_add(&wlr_output->events.frame, &output->frame);
	output->request_state.notify = output_request_state;
	wl_signal_add(&wlr_output->events.request_state, &output->request_state);
	output->destroy.notify = output_destroy;
	wl_signal_add(&wlr_output->events.destroy, &output->destroy);
	wl_list_insert(&server->outputs, &output->link);

	struct wlr_output_layout_output *l_output =
		wlr_output_layout_add_auto(server->output_layout, wlr_output);
	struct wlr_scene_output *scene_output = wlr_scene_output_create(server->scene, wlr_output);
	wlr_scene_output_layout_add_output(server->scene_layout, l_output, scene_output);

	struct wlr_box box;
	wlr_output_layout_get_box(server->output_layout, wlr_output, &box);
	output->usable_area = box;
	output->bg = wlr_scene_rect_create(server->tree_bg, box.width, box.height, COLOR_BG);
	wlr_scene_node_set_position(&output->bg->node, box.x, box.y);
	output->lock_rect = wlr_scene_rect_create(server->tree_lock, box.width, box.height, COLOR_BLACK);
	wlr_scene_node_set_position(&output->lock_rect->node, box.x, box.y);
	wlr_scene_node_set_enabled(&output->lock_rect->node, server->locked);
}

/* ------------------------------------------------------------ main */

static void sigchld_handler(int sig) {
	while (waitpid(-1, NULL, WNOHANG) > 0) {}
}

int main(int argc, char *argv[]) {
	wlr_log_init(WLR_INFO, NULL);
	char *startup_cmd = NULL;

	int c;
	while ((c = getopt(argc, argv, "s:h")) != -1) {
		switch (c) {
		case 's':
			startup_cmd = optarg;
			break;
		default:
			printf("Usage: %s [-s startup command]\n", argv[0]);
			return 0;
		}
	}

	struct sigaction sa = {.sa_handler = sigchld_handler, .sa_flags = SA_RESTART | SA_NOCLDSTOP};
	sigaction(SIGCHLD, &sa, NULL);

	struct mk_server server = {0};
	server.display = wl_display_create();
	server.backend = wlr_backend_autocreate(server.display, NULL);
	if (server.backend == NULL) {
		wlr_log(WLR_ERROR, "failed to create wlr_backend");
		return 1;
	}
	server.renderer = wlr_renderer_autocreate(server.backend);
	if (server.renderer == NULL) {
		wlr_log(WLR_ERROR, "failed to create wlr_renderer");
		return 1;
	}
	wlr_renderer_init_wl_display(server.renderer, server.display);
	server.allocator = wlr_allocator_autocreate(server.backend, server.renderer);
	if (server.allocator == NULL) {
		wlr_log(WLR_ERROR, "failed to create wlr_allocator");
		return 1;
	}

	wlr_compositor_create(server.display, 5, server.renderer);
	wlr_subcompositor_create(server.display);
	wlr_data_device_manager_create(server.display);

	server.output_layout = wlr_output_layout_create();
	wl_list_init(&server.outputs);
	server.new_output.notify = server_new_output;
	wl_signal_add(&server.backend->events.new_output, &server.new_output);

	server.scene = wlr_scene_create();
	server.scene_layout = wlr_scene_attach_output_layout(server.scene, server.output_layout);
	server.tree_bg = wlr_scene_tree_create(&server.scene->tree);
	server.tree_layer_bg = wlr_scene_tree_create(&server.scene->tree);
	server.tree_layer_bottom = wlr_scene_tree_create(&server.scene->tree);
	server.tree_windows = wlr_scene_tree_create(&server.scene->tree);
	server.tree_layer_top = wlr_scene_tree_create(&server.scene->tree);
	server.tree_switcher = wlr_scene_tree_create(&server.scene->tree); /* above windows/panels, below overlay */
	server.tree_layer_overlay = wlr_scene_tree_create(&server.scene->tree);
	server.tree_lock = wlr_scene_tree_create(&server.scene->tree); /* always topmost */

	wl_list_init(&server.toplevels);
	server.xdg_shell = wlr_xdg_shell_create(server.display, 3);
	server.new_xdg_surface.notify = server_new_xdg_surface;
	wl_signal_add(&server.xdg_shell->events.new_surface, &server.new_xdg_surface);

	wl_list_init(&server.layer_surfaces);
	server.layer_shell = wlr_layer_shell_v1_create(server.display, 4);
	server.new_layer_surface.notify = server_new_layer_surface;
	wl_signal_add(&server.layer_shell->events.new_surface, &server.new_layer_surface);

	server.foreign_toplevel_manager = wlr_foreign_toplevel_manager_v1_create(server.display);
	server.inhibit_mgr = wlr_idle_inhibit_v1_create(server.display);
	server.new_inhibitor.notify = server_new_inhibitor;
	wl_signal_add(&server.inhibit_mgr->events.new_inhibitor, &server.new_inhibitor);
	server.gamma_mgr = wlr_gamma_control_manager_v1_create(server.display);
	server.set_gamma.notify = handle_set_gamma;
	wl_signal_add(&server.gamma_mgr->events.set_gamma, &server.set_gamma);
	server.lock_mgr = wlr_session_lock_manager_v1_create(server.display);
	server.new_lock.notify = server_new_lock;
	wl_signal_add(&server.lock_mgr->events.new_lock, &server.new_lock);
	{
		struct wl_event_loop *loop = wl_display_get_event_loop(server.display);
		server.lock_timer = wl_event_loop_add_timer(loop, lock_timer_cb, &server);
		server.idle_timer = wl_event_loop_add_timer(loop, idle_cb, &server);
		server.blank_timer = wl_event_loop_add_timer(loop, blank_cb, &server);
	}
	wlr_screencopy_manager_v1_create(server.display); /* grim screenshots */
	wlr_xdg_output_manager_v1_create(server.display, server.output_layout);
	wlr_primary_selection_v1_device_manager_create(server.display);

	server.cursor = wlr_cursor_create();
	wlr_cursor_attach_output_layout(server.cursor, server.output_layout);
	server.cursor_mgr = wlr_xcursor_manager_create(NULL, 24);
	server.cursor_mode = CURSOR_PASSTHROUGH;
	server.cursor_motion.notify = server_cursor_motion;
	wl_signal_add(&server.cursor->events.motion, &server.cursor_motion);
	server.cursor_motion_absolute.notify = server_cursor_motion_absolute;
	wl_signal_add(&server.cursor->events.motion_absolute, &server.cursor_motion_absolute);
	server.cursor_button.notify = server_cursor_button;
	wl_signal_add(&server.cursor->events.button, &server.cursor_button);
	server.cursor_axis.notify = server_cursor_axis;
	wl_signal_add(&server.cursor->events.axis, &server.cursor_axis);
	server.cursor_frame.notify = server_cursor_frame;
	wl_signal_add(&server.cursor->events.frame, &server.cursor_frame);

	wl_list_init(&server.keyboards);
	server.new_input.notify = server_new_input;
	wl_signal_add(&server.backend->events.new_input, &server.new_input);
	server.seat = wlr_seat_create(server.display, "seat0");
	server.request_cursor.notify = seat_request_cursor;
	wl_signal_add(&server.seat->events.request_set_cursor, &server.request_cursor);
	server.request_set_selection.notify = seat_request_set_selection;
	wl_signal_add(&server.seat->events.request_set_selection, &server.request_set_selection);

	const char *socket = wl_display_add_socket_auto(server.display);
	if (!socket) {
		wlr_backend_destroy(server.backend);
		return 1;
	}
	if (!wlr_backend_start(server.backend)) {
		wlr_backend_destroy(server.backend);
		wl_display_destroy(server.display);
		return 1;
	}

	setenv("WAYLAND_DISPLAY", socket, true);
	setenv("XDG_CURRENT_DESKTOP", "Vespara", true);
	setenv("XDG_SESSION_TYPE", "wayland", true);
	ipc_start(&server);
	if (startup_cmd) {
		spawn(startup_cmd);
	}

	wlr_log(WLR_INFO, "Vespara OS compositor running on WAYLAND_DISPLAY=%s", socket);
	wl_display_run(server.display);

	wl_display_destroy_clients(server.display);
	wlr_scene_node_destroy(&server.scene->tree.node);
	wlr_xcursor_manager_destroy(server.cursor_mgr);
	wlr_cursor_destroy(server.cursor);
	wlr_allocator_destroy(server.allocator);
	wlr_renderer_destroy(server.renderer);
	wlr_backend_destroy(server.backend);
	wl_display_destroy(server.display);
	return 0;
}
