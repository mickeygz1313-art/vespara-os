project('vespara-wm', 'c',
  version: '0.1.0',
  default_options: ['c_std=c11', 'warning_level=2', 'werror=false'])

add_project_arguments(['-DWLR_USE_UNSTABLE', '-Wno-unused-parameter'], language: 'c')

wlroots    = dependency('wlroots', version: ['>=0.17.0', '<0.18.0'])
wl_server  = dependency('wayland-server')
xkbcommon  = dependency('xkbcommon')
wl_protos  = dependency('wayland-protocols')
scanner    = find_program('wayland-scanner')

wl_pdir = wl_protos.get_variable('pkgdatadir')

xdg_xml   = join_paths(wl_pdir, 'stable/xdg-shell/xdg-shell.xml')
layer_xml = files('protocols/wlr-layer-shell-unstable-v1.xml')

protos = []
protos += custom_target('xdg-shell-header',
  input: xdg_xml, output: 'xdg-shell-protocol.h',
  command: [scanner, 'server-header', '@INPUT@', '@OUTPUT@'])
protos += custom_target('layer-shell-header',
  input: layer_xml, output: 'wlr-layer-shell-unstable-v1-protocol.h',
  command: [scanner, 'server-header', '@INPUT@', '@OUTPUT@'])

executable('vespara-wm', 'src/main.c', protos,
  dependencies: [wlroots, wl_server, xkbcommon],
  install: true)
